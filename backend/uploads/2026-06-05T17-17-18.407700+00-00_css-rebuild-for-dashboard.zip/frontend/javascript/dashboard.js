let allNotifications = [];
let currentFilter = "all";
let notificationClock = null;
let dashboardThemeMediaQuery = null;
let dashboardThemeMediaQueryHandlerBound = false;
let dashboardPageInitialized = false;
const DASHBOARD_VIEW_IDS = [
    "dashboard-view",
    "tasks-view",
    "team-view",
    "calendar-view",
    "activity-view",
    "files-view",
    "profile-view",
    "settings-view",
    "project-workspace-view",
    "report-view"
];
const STATUS_COLOR_FALLBACKS = {
    pending: "#f59e0b",
    progress: "#2563eb",
    completed: "#16a34a",
    hold: "#d92d20",
    planning: "#9333ea"
};

function getStatusColorToken(name) {
    const value = getComputedStyle(document.documentElement).getPropertyValue(`--status-${name}`).trim();
    return value || STATUS_COLOR_FALLBACKS[name] || STATUS_COLOR_FALLBACKS.pending;
}

const params = new URLSearchParams(window.location.search);

const token = params.get("token");
const role = params.get("role");
const username = params.get("username");
const email = params.get("email");

if (token) {
    sessionStorage.setItem("token", token);
    sessionStorage.setItem("role", role || "user");
    sessionStorage.setItem("username", username || "");
    sessionStorage.setItem("email", email || "");

    window.history.replaceState({}, document.title, "/dashboard-page");
}
    
function hideAllViews() {
    DASHBOARD_VIEW_IDS.forEach((id) => {
        document.getElementById(id)?.classList.add("hidden");
    });
}

function showView(viewId) {
    hideAllViews();
    const view = document.getElementById(viewId);
    if (view) {
        view.classList.remove('hidden');
    }
}

function setActiveMenu(menuName) {
    document.querySelectorAll('.menu-item').forEach(item => {
        item.classList.remove('active');
    });
    const activeItem = document.querySelector(`[data-sidebar="${menuName}"]`);
    if (activeItem) {
        activeItem.classList.add('active');
    }
}

function dashboard() {
    setActiveMenu('dashboard');
    showView('dashboard-view');
    loadProjects();
}

function setProjectTab(tab) {
    if ((tab === 'activity-log' || tab === 'report') && sessionStorage.getItem("role") === "user") {
        dashboard();
        return;
    }

    switch(tab) {
        case 'overview':
            setActiveMenu('overview');
            showView('dashboard-view');
            loadProjects();
            break;
        case 'tasks':
            setActiveMenu('tasks');
            showView('tasks-view');
            loadAllTasks();
            break;
        case 'team':
            setActiveMenu('team');
            showView('team-view');
            loadTeamMembers();
            break;
        case 'calendar':
            setActiveMenu('calendar');
            showView('calendar-view');
            initializeCalendar();
            break;
        case 'activity-log':
            setActiveMenu('activity-log');
            showView('activity-view');
            loadActivityLog();
            break;
        case 'report':
            setActiveMenu('report');
            showView('report-view');
            loadReports();
            break;
        case 'files':
            setActiveMenu('files');
            showView('files-view');
            loadFiles();
            break;
        case 'settings':
            goToSettings();
            break;
    }
}

function goToSettings() {
    setActiveMenu('settings');
    showView('settings-view');
    loadSettingsView();
}

async function goToProfile() {
    setActiveMenu('');
    showView('profile-view');
    await loadDashboardProfile();
}

async function loadDashboardProfile() {
    const username = sessionStorage.getItem("username") || "User";
    const email = sessionStorage.getItem("email") || "";
    const role = sessionStorage.getItem("role") || "user";
    const token = sessionStorage.getItem("token");

    if (!email) {
        alert("No user data found. Please login again.");
        window.location.href = "/";
        return;
    }

    const initial = (username || email).charAt(0).toUpperCase();
    const roleText = role.charAt(0).toUpperCase() + role.slice(1);

    const binds = {
        "dashboard-profile-avatar-large": initial,
        "dashboard-profile-name": username,
        "dashboard-profile-role-text": roleText,
        "dashboard-profile-username": username,
        "dashboard-profile-email": email,
        "dashboard-profile-role": roleText
    };

    Object.entries(binds).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    });

    if (!token) return;

    try {
        const [projectsRes, tasksRes] = await Promise.all([
            fetch(`${BASE_URL}/projects`, {
                headers: { "Authorization": "Bearer " + token }
            }),
            fetch(`${BASE_URL}/tasks`, {
                headers: { "Authorization": "Bearer " + token }
            })
        ]);
        const projects = await projectsRes.json();
        const tasks = await tasksRes.json();
        
    } catch (error) {
        console.error("Failed to load profile summary", error);
    }
}

function loadSettingsView() {
    const themeSelect = document.getElementById("settings-theme-select");
    const languageSelect = document.getElementById("settings-language-select");
    if (themeSelect) themeSelect.value = sessionStorage.getItem("settings.theme") || "light";
    if (languageSelect) {
        languageSelect.value = getSavedDashboardLanguage();
    }
    applySettingsPreferences();
}

function saveSettingsPreference(key, value) {
    sessionStorage.setItem(`settings.${key}`, String(value));

    if (key === "language") {
        const lang = value === "hindi" ? "hi" : "en";

        const interval = setInterval(() => {
            const combo = document.querySelector(".goog-te-combo");
            if (combo) {
                combo.value = lang;
                combo.dispatchEvent(new Event("change"));
                clearInterval(interval);
            }
        }, 500);
    }

    applySettingsPreferences();
}

function changeGoogleLanguage(lang) {
    localStorage.setItem("selectedLanguage", lang);
    sessionStorage.setItem("settings.language", lang);

    const select = document.getElementById("settings-language-select");
    if (select) select.value = lang;

    document.cookie = "googtrans=/en/" + lang + ";path=/";
    document.cookie =
        "googtrans=/en/" + lang +
        ";domain=" + location.hostname + ";path=/";

    const apply = () => {
        const combo = document.querySelector(".goog-te-combo");

        if (combo) {
            combo.value = lang;
            combo.dispatchEvent(new Event("change"));
        } else {
            setTimeout(apply, 300);
        }
    };

    apply();
}

function getSavedDashboardLanguage() {
    const savedPreference =
        String(sessionStorage.getItem("settings.language") || "").trim().toLowerCase();

    if (savedPreference === "hi" || savedPreference === "hindi") {
        return "hi";
    }

    if (savedPreference === "en" || savedPreference === "english") {
        return "en";
    }

    return localStorage.getItem("selectedLanguage") || "en";
}

function getTaskAssignedBy(task, project) {
    return task.assigned_by || task.assigned_by_email || task.created_by || project?.owner_email || project?.assigned_manager || "Unknown";
}

function getTaskAssignments(task) {
    if (Array.isArray(task?.assignments)) return task.assignments;
    if (Array.isArray(task?.assigned_statuses)) return task.assigned_statuses;

    const assigned = Array.isArray(task?.assigned_to)
        ? task.assigned_to
        : (task?.assigned_to ? [task.assigned_to] : []);

    return assigned.map(email => ({
        user_id: email,
        status: normalizeMemberStatus(task?.status)
    }));
}

function normalizeMemberStatus(status) {
    const value = String(status || "Pending").trim().toLowerCase();
    if (value === "todo" || value === "pending") return "Pending";
    if (value === "in progress" || value === "progress") return "In Progress";
    if (value === "done" || value === "completed") return "Completed";
    if (value === "on hold" || value === "hold") return "On Hold";
    if (value === "planning" || value === "planned") return "Planning";
    return "Pending";
}

function memberStatusClass(status) {
    return normalizeMemberStatus(status).toLowerCase().replace(/\s+/g, "-");
}

function getMyAssignment(task) {
    const email = (sessionStorage.getItem("email") || "").trim().toLowerCase();
    return getTaskAssignments(task).find(assignment =>
        String(assignment.user_id || "").trim().toLowerCase() === email
    );
}

function userIsAssignedToTask(task, email) {
    const lookup = String(email || "").trim().toLowerCase();
    return getTaskAssignments(task).some(assignment =>
        String(assignment.user_id || "").trim().toLowerCase() === lookup
    );
}

function renderMemberStatusBadges(task, options = {}) {
    const assignments = getTaskAssignments(task);
    const compact = options.compact ? " compact" : "";

    if (!assignments.length) {
        return `<span class="member-status-empty">Unassigned</span>`;
    }

    return `
        <div class="member-status-list${compact}">
            ${assignments.map(assignment => {
                const email = String(assignment.user_id || "Unassigned");
                const status = normalizeMemberStatus(assignment.status);
                const label = options.showEmail === false ? status : `${email} - ${status}`;
                return `
                    <span class="member-status-badge ${memberStatusClass(status)}" title="${escapeTeamHtml(email)}: ${status}">
                        <span class="member-status-dot"></span>
                        <span>${escapeTeamHtml(label)}</span>
                    </span>
                `;
            }).join("")}
        </div>
    `;
}

function renderAssigneeList(task, options = {}) {
    const assignments = getTaskAssignments(task);
    const compact = options.compact ? " compact" : "";

    if (!assignments.length) {
        return `<span class="member-status-empty">Unassigned</span>`;
    }

    return `
        <div class="assignee-list${compact}">
            ${assignments.map(assignment => {
                const email = String(assignment.user_id || "Unassigned");
                return `
                    <span class="assignee-pill" title="${escapeTeamHtml(email)}">
                        <i class="fas fa-user"></i>
                        <span>${escapeTeamHtml(email)}</span>
                    </span>
                `;
            }).join("")}
        </div>
    `;
}

function renderMyStatusControl(task) {
    const assignment = getMyAssignment(task);
    const status = normalizeMemberStatus(assignment?.status);

    if (!assignment) {
        return `<span class="member-status-empty">Not assigned</span>`;
    }

    return `
        <select class="member-status-select" onchange="updateStatus('${task.id}', this.value)">
            <option value="Pending" ${status === "Pending" ? "selected" : ""}>Pending</option>
            <option value="In Progress" ${status === "In Progress" ? "selected" : ""}>In Progress</option>
            <option value="Completed" ${status === "Completed" ? "selected" : ""}>Completed</option>
            <option value="On Hold" ${status === "On Hold" ? "selected" : ""}>On Hold</option>
            <option value="Planning" ${status === "Planning" ? "selected" : ""}>Planning</option>
        </select>
    `;
}

function toggleQuietNotifications() {
    const nextValue = sessionStorage.getItem("settings.quietNotifications") !== "true";
    saveSettingsPreference("quietNotifications", nextValue);
}

function applySettingsPreferences() {
    const compactTables = sessionStorage.getItem("settings.compactTables") === "true";
    const quietNotifications = sessionStorage.getItem("settings.quietNotifications") === "true";
    const theme = sessionStorage.getItem("settings.theme") || "light";
    const resolvedTheme = getResolvedDashboardTheme(theme);
    document.body.classList.toggle("compact-dashboard-tables", compactTables);
    document.body.classList.toggle("quiet-dashboard-notifications", quietNotifications);
    document.body.classList.toggle("dashboard-theme-dark", resolvedTheme === "dark");
    document.documentElement.dataset.dashboardTheme = resolvedTheme;

    const notificationState = document.getElementById("settings-notification-state");
    if (notificationState) {
        notificationState.textContent = quietNotifications ? "Muted" : "On";
        notificationState.classList.toggle("muted", quietNotifications);
    }

}

function getResolvedDashboardTheme(theme) {
    if (theme === "system") {
        return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
    return theme;
}

function bindDashboardThemePreference() {
    if (!window.matchMedia) {
        return;
    }

    if (!dashboardThemeMediaQuery) {
        dashboardThemeMediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
    }

    if (dashboardThemeMediaQueryHandlerBound) {
        return;
    }

    const handleThemePreferenceChange = () => {
        if ((sessionStorage.getItem("settings.theme") || "light") === "system") {
            applySettingsPreferences();
        }
    };

    if (typeof dashboardThemeMediaQuery.addEventListener === "function") {
        dashboardThemeMediaQuery.addEventListener("change", handleThemePreferenceChange);
    } else if (typeof dashboardThemeMediaQuery.addListener === "function") {
        dashboardThemeMediaQuery.addListener(handleThemePreferenceChange);
    }

    dashboardThemeMediaQueryHandlerBound = true;
}


function goBack() {
    hideAllViews();
    document.getElementById('dashboard-view').classList.remove('hidden');
}

let activeTaskId = null;
let filesCache = [];
let filesTab = "all";
let filesCategory = "all";
let filesSort = "name-asc";
let filesLayout = "grid";
let filesPage = 1;
const filesPageSize = 10;
const expandedFileAssigneeRows = new Set();
let fileAssigneeToggleBound = false;
let fileAssigneePopoverBound = false;
let activeFileAssigneePreview = null;
let assignableUsers = [];
let fileUploadProjects = [];
let fileUploadTasks = [];
let fileUploadSelectedFile = null;
let fileUploadSelectedAssignees = [];
let teamMemberCache = [];
let expandedTeamProjects = {};
let allUsersCache = [];
let teamWorkspaceCache = {
    projects: [],
    tasks: [],
    users: []
};
let dashboardTaskCache = {
    projects: [],
    tasks: [],
    users: []
};
let dashboardTaskPage = 1;
const dashboardTaskPageSize = 5;
let selectedDashboardTaskId = sessionStorage.getItem("taskflow.selectedTaskId") || null;
let dashboardTaskDetailOpen = false;
let dashboardTaskEditMode = false;
let dashboardTaskInboxScrollTop = Number(sessionStorage.getItem("taskflow.taskInboxScrollTop") || 0);
const dashboardSelectedTaskIds = new Set();
let projectWorkspaceTaskPage = 1;
const projectWorkspaceTaskPageSize = 5;
let expandedTaskAssigneeCards = {};

function getUserDisplayName(email, users = []) {
    const lookup = String(email || "").trim().toLowerCase();
    const user = users.find(item => String(item.email || "").trim().toLowerCase() === lookup);
    return user?.username || String(email || "Unassigned").split("@")[0] || "Unassigned";
}

function getAvatarInitial(nameOrEmail) {
    return String(nameOrEmail || "?").trim().charAt(0).toUpperCase() || "?";
}

function isTaskAssigneeCardExpanded(taskId) {
    return Boolean(expandedTaskAssigneeCards[String(taskId || "")]);
}

function toggleTaskAssigneeCard(taskId) {
    const key = String(taskId || "");
    if (!key) return;

    expandedTaskAssigneeCards[key] = !isTaskAssigneeCardExpanded(key);
    renderDashboardTaskBoard();

    const workspaceView = document.getElementById("project-workspace-view");
    if (workspaceView && !workspaceView.classList.contains("hidden")) {
        loadProjectWorkspace();
    }
}

function renderTaskAssigneeStatusList(task, users = [], options = {}) {
    const assignments = getTaskAssignments(task);
    const baseVisibleCount = options.limit || 1;
    const isExpanded = isTaskAssigneeCardExpanded(task?.id);
    const visibleCount = isExpanded ? assignments.length : baseVisibleCount;
    const visibleAssignments = assignments.slice(0, visibleCount);
    const hiddenAssignments = assignments.slice(visibleCount);
    const remaining = hiddenAssignments.length;

    if (!assignments.length) {
        return `<span class="member-status-empty">Unassigned</span>`;
    }

    return `
        <div class="task-assignee-card">
            ${visibleAssignments.map(assignment => {
                const email = String(assignment.user_id || "Unassigned");
                const name = getUserDisplayName(email, users);
                const status = normalizeMemberStatus(assignment.status);
                return `
                    <div class="task-assignee-row">
                        <span class="task-assignee-avatar">${escapeTeamHtml(getAvatarInitial(name || email))}</span>
                        <span class="task-assignee-name">${escapeTeamHtml(name)}</span>
                        <span class="task-assignee-status ${memberStatusClass(status)}">
                            <span></span>${escapeTeamHtml(status)}
                        </span>
                    </div>
                `;
            }).join("")}
            ${remaining ? `
                <button class="task-more-btn" type="button" onclick="toggleTaskAssigneeCard('${task.id}')">+ ${remaining} more</button>
            ` : ""}
            ${!remaining && isExpanded && assignments.length > baseVisibleCount ? `
                <button class="task-more-btn" type="button" onclick="toggleTaskAssigneeCard('${task.id}')">Show less</button>
            ` : ""}
        </div>
    `;
}

function getTaskAttachmentItems(task) {
    return Array.isArray(task?.attachments) ? task.attachments.filter(Boolean) : [];
}

function renderTaskAttachments(task) {
    const attachments = getTaskAttachmentItems(task);
    if (!attachments.length) return "";

    return `
        <div class="task-attachment-list">
            ${attachments.map((attachment, index) => {
                const name = typeof attachment === "string"
                    ? attachment
                    : (attachment?.name || attachment?.stored_name || `Attachment ${index + 1}`);
                const storedName = typeof attachment === "string"
                    ? attachment
                    : (attachment?.stored_name || attachment?.name || "");

                if (!storedName) return "";

                return `
                    <button
                        class="task-attachment-chip"
                        type="button"
                        onclick="downloadTaskAttachment('${escapeTeamHtml(task.id)}', '${escapeTeamHtml(encodeURIComponent(storedName))}', '${escapeTeamHtml(encodeURIComponent(name))}')"
                        title="${escapeTeamHtml(name)}"
                    >
                        <i class="fas fa-paperclip"></i>
                        <span>${escapeTeamHtml(name)}</span>
                    </button>
                `;
            }).join("")}
        </div>
    `;
}

async function downloadTaskAttachment(taskId, encodedStoredName, encodedFileName) {
    const token = sessionStorage.getItem("token");
    if (!token || !taskId || !encodedStoredName) return;

    try {
        const storedName = decodeURIComponent(encodedStoredName);
        const fileName = encodedFileName ? decodeURIComponent(encodedFileName) : storedName;
        const response = await fetch(`${BASE_URL}/tasks/${encodeURIComponent(taskId)}/attachments/${encodeURIComponent(storedName)}`, {
            headers: {
                "Authorization": "Bearer " + token
            }
        });

        if (!response.ok) {
            const data = await response.json().catch(() => ({}));
            throw new Error(data.detail || data.message || "Unable to download attachment");
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(url);
    } catch (error) {
        console.error("Failed to download task attachment", error);
        alert(error.message || "Unable to download attachment");
    }
}

function populateDashboardTaskFilters(projects) {
    const projectFilter = document.getElementById("taskProjectFilter");
    if (!projectFilter) return;

    const current = projectFilter.value || "all";
    projectFilter.innerHTML = `<option value="all">All Projects</option>`;

    projects.forEach(project => {
        const option = document.createElement("option");
        option.value = String(project.id);
        option.textContent = project.name || "Untitled Project";
        projectFilter.appendChild(option);
    });

    projectFilter.value = Array.from(projectFilter.options).some(option => option.value === current)
        ? current
        : "all";
}

function getFilteredDashboardTasks() {
    const query = (document.getElementById("taskSearchInput")?.value || "").trim().toLowerCase();
    const projectId = document.getElementById("taskProjectFilter")?.value || "all";
    const priorityFilter = document.getElementById("taskPriorityFilter")?.value || "all";
    const status = document.getElementById("taskStatusFilter")?.value || "all";
    const dueFilter = document.getElementById("taskDueFilter")?.value || "all";
    const sortValue = document.getElementById("taskSortSelect")?.value || "newest";
    const { projects, tasks, users } = dashboardTaskCache;

    const filtered = tasks.filter(task => {
        const project = projects.find(item => String(item.id) === String(task.project_id));
        const assignments = getTaskAssignments(task);
        const priority = normalizeDashboardTaskPriority(task.priority);
        const taskStatus = normalizeMemberStatus(task.status);

        if (projectId !== "all" && String(task.project_id) !== String(projectId)) return false;
        if (priorityFilter !== "all" && priority !== priorityFilter) return false;
        if (status !== "all" && taskStatus !== status) return false;
        if (!dashboardTaskMatchesDueFilter(task, dueFilter)) return false;

        if (!query) return true;

        const searchValues = [
            task.title,
            task.description,
            project?.name,
            priority,
            taskStatus,
            task.deadline,
            ...assignments.flatMap(assignment => [
                assignment.user_id,
                getUserDisplayName(assignment.user_id, users),
                normalizeMemberStatus(assignment.status)
            ])
        ];

        return searchValues.some(value => String(value || "").toLowerCase().includes(query));
    });

    return filtered.sort((a, b) => compareDashboardTasks(a, b, sortValue));
}

function renderDashboardTaskBoard() {
    const list = document.getElementById("all-tasks-list");
    if (!list) return;

    const role = sessionStorage.getItem("role");
    const tasks = getFilteredDashboardTasks();
    const totalPages = Math.max(Math.ceil(tasks.length / dashboardTaskPageSize), 1);
    dashboardTaskPage = Math.min(Math.max(dashboardTaskPage, 1), totalPages);
    const startIndex = (dashboardTaskPage - 1) * dashboardTaskPageSize;
    const pageTasks = tasks.slice(startIndex, startIndex + dashboardTaskPageSize);
    const taskAddButton = document.getElementById("taskAddButton");
    document.querySelector(".task-inbox-shell")?.classList.toggle("showing-detail", Boolean(dashboardTaskDetailOpen));

    if (taskAddButton) taskAddButton.style.display = role === "manager" ? "" : "none";

    if (!tasks.length) {
        list.innerHTML = `
            <div class="task-inbox-empty-list">
                <i class="fas fa-magnifying-glass"></i>
                <strong>No tasks found</strong>
                <span>Adjust the search or filters to see more tasks.</span>
            </div>
        `;
        renderDashboardTaskPagination(0, 0, 0, 1, 1);
        if (dashboardTaskDetailOpen && !selectedDashboardTaskId) renderTaskEmptyState();
        return;
    }

    if (selectedDashboardTaskId && !dashboardTaskCache.tasks.some(task => String(task.id) === String(selectedDashboardTaskId))) {
        selectedDashboardTaskId = null;
        dashboardTaskDetailOpen = false;
        sessionStorage.removeItem("taskflow.selectedTaskId");
    }

    list.innerHTML = pageTasks.map(task => renderTaskListItem(task)).join("");
    if (dashboardTaskDetailOpen) {
        renderDashboardTaskDetail();
    }
    restoreDashboardTaskInboxScroll();
    updateTaskBulkState();
    renderDashboardTaskPagination(startIndex + 1, startIndex + pageTasks.length, tasks.length, dashboardTaskPage, totalPages);
}

function renderDashboardTaskSkeleton() {
    const list = document.getElementById("all-tasks-list");
    const detail = document.getElementById("task-detail-content");
    if (list) {
        list.innerHTML = Array.from({ length: 7 }).map(() => `
            <div class="task-list-item task-list-skeleton">
                <span></span><div></div><div></div>
            </div>
        `).join("");
    }
    if (detail) {
        detail.innerHTML = `
            <div class="task-detail-skeleton">
                <span></span><span></span><span></span><span></span>
            </div>
        `;
    }
}

function renderTaskListItem(task) {
    const { projects, users } = dashboardTaskCache;
    const project = projects.find(item => String(item.id) === String(task.project_id));
    const status = normalizeMemberStatus(task.status);
    const statusClass = memberStatusClass(status);
    const priority = normalizeDashboardTaskPriority(task.priority);
    const priorityClass = priority.toLowerCase().replace(/\s+/g, "-");
    const attachments = getTaskAttachmentItems(task);
    const assignments = getTaskAssignments(task);
    const checked = dashboardSelectedTaskIds.has(String(task.id)) ? "checked" : "";
    const selected = String(task.id) === String(selectedDashboardTaskId) ? "selected" : "";
    const description = getTaskPreview(task.description || "No description added.");

    return `
        <article class="task-list-item ${selected}" role="button" tabindex="0" data-task-id="${escapeTeamHtml(task.id)}" onclick="selectDashboardTask('${escapeTeamHtml(task.id)}')" onkeydown="handleTaskListItemKeydown(event, '${escapeTeamHtml(task.id)}')">
            <div class="task-list-controls" onclick="event.stopPropagation()">
                <button class="task-star-btn" type="button" onclick="toggleTaskStar(event, '${escapeTeamHtml(task.id)}')" aria-label="Mark important">
                    <i class="${isDashboardTaskStarred(task.id) ? "fas" : "far"} fa-star"></i>
                </button>
            </div>
            <div class="task-list-main">
                <div class="task-list-title-row">
                    <strong>${escapeTeamHtml(task.title || "Untitled Task")}</strong>
                    <span class="task-list-date">
                        ${escapeTeamHtml(formatCreatedDate(task.created_at || task.updated_at))}
                    </span>
                </div>
                <p>${escapeTeamHtml(description)}</p>
                <div class="task-list-meta">
                    <span class="task-project-name">${escapeTeamHtml(project?.name || "Unknown Project")}</span>
                    <span class="task-assignee-avatars" title="${escapeTeamHtml(assignments.map(item => item.user_id).join(", ") || "Unassigned")}">
                        ${renderTaskAvatarStack(assignments, users)}
                    </span>
                    <span class="task-priority-pill ${priorityClass}">${escapeTeamHtml(priority)}</span>
                    <span class="status-pill ${statusClass}">${escapeTeamHtml(status)}</span>
                    ${attachments.length ? `<span class="task-attachment-indicator"><i class="fas fa-paperclip"></i>${attachments.length}</span>` : ""}
                </div>
            </div>
        </article>
    `;
}

function formatCreatedDate(value) {
    if (!value) return "";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) return "";

    return date.toLocaleString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
    }).replace(",", "");
}

function renderDashboardTaskDetail() {
    const task = getSelectedDashboardTask();
    if (!task) {
        renderTaskEmptyState();
        return;
    }

    const detail = document.getElementById("task-detail-content");
    if (!detail) return;

    const role = sessionStorage.getItem("role");
    const project = dashboardTaskCache.projects.find(item => String(item.id) === String(task.project_id));

    detail.innerHTML = dashboardTaskEditMode
        ? renderTaskEditPanel(task, project)
        : renderTaskReadPanel(task, project, role);
}

function renderTaskReadPanel(task, project, role) {
    const status = normalizeMemberStatus(task.status);
    const statusClass = memberStatusClass(status);
    const priority = normalizeDashboardTaskPriority(task.priority);
    const priorityClass = priority.toLowerCase().replace(/\s+/g, "-");
    const canManage = role === "manager" || role === "admin";
    const assignedBy = getTaskAssignedBy(task, project);
    const assignedByName = getUserDisplayName(assignedBy, dashboardTaskCache.users);

    return `
        <div class="task-detail-header">
            <div class="task-detail-title-group">
                <span class="task-detail-kicker">Task Details</span>
                <h2>${escapeTeamHtml(task.title || "Untitled Task")}</h2>
                <p><i class="fas fa-folder"></i>${escapeTeamHtml(project?.name || "Unknown Project")}</p>
            </div>

            <div class="task-detail-actions">
                <button class="task-detail-back" type="button" onclick="clearDashboardTaskSelection()" aria-label="Back to task list">
                    <i class="fas fa-arrow-left"></i>
                    <span>Back</span>
                </button>
                ${canManage ? `<button type="button" onclick="enterDashboardTaskEditMode()"><i class="fas fa-pen"></i>Edit</button>` : ""}
                ${canManage ? `<button class="danger" type="button" onclick="deleteTask('${escapeTeamHtml(task.id)}')"><i class="fas fa-trash"></i>Delete</button>` : ""}
            </div>
        </div>

        <section class="task-detail-grid">
            <div><span>Project</span><strong>${escapeTeamHtml(project?.name || "Unknown")}</strong></div>
            <div><span>Assigned by</span><strong title="${escapeTeamHtml(assignedBy)}">${escapeTeamHtml(assignedByName || assignedBy)}</strong></div>
            <div><span>Priority</span><strong><span class="task-priority-pill ${priorityClass}">${escapeTeamHtml(priority)}</span></strong></div>
            <div><span>Status</span><strong>${renderDashboardStatusControl(task, role, statusClass)}</strong></div>
            <div><span>Due date</span><strong>${escapeTeamHtml(formatDeadlineDate(task.deadline || task.due_date))}</strong></div>
        </section>

        <section class="task-detail-section">
            <h3>Description</h3>
            <p class="task-detail-description">${escapeTeamHtml(task.description || "No description added.")}</p>
        </section>

        <section class="task-detail-section">
            <h3>Assigned Members</h3>
            ${renderTaskDetailAssignees(task)}
        </section>

        <section class="task-detail-section">
            <h3>Attachments</h3>
            ${renderTaskAttachments(task) || `<p class="task-muted">No attachments.</p>`}
        </section>

        ${renderTaskTimeline(task)}
        ${renderTaskComments(task)}
        ${renderTaskHistory(task)}
    `;
}

function renderTaskEditPanel(task, project) {
    const priority = normalizeDashboardTaskPriority(task.priority);
    const status = normalizeMemberStatus(task.status);
    return `
        <form class="task-edit-panel" onsubmit="saveDashboardTaskEdit(event, '${escapeTeamHtml(task.id)}')">
            <div class="task-detail-header">
                <button class="task-detail-back" type="button" onclick="exitDashboardTaskEditMode()" aria-label="Cancel edit">
                    <i class="fas fa-arrow-left"></i>
                </button>
                <div>
                    <h2>Edit Task</h2>
                    <p>${escapeTeamHtml(project?.name || "Unknown Project")}</p>
                </div>
            </div>
            <label>Title<input id="taskEditTitle" value="${escapeTeamHtml(task.title || "")}" required></label>
            <label>Description<textarea id="taskEditDescription" rows="5">${escapeTeamHtml(task.description || "")}</textarea></label>
            <div class="task-edit-grid">
                <label>Priority
                    <select id="taskEditPriority">
                        ${["Low", "Medium", "High", "Urgent"].map(item => `<option value="${item}" ${priority === item ? "selected" : ""}>${item}</option>`).join("")}
                    </select>
                </label>
                <label>Status
                    <select id="taskEditStatus">
                        ${["Pending", "In Progress", "Completed", "On Hold", "Planning"].map(item => `<option value="${item}" ${status === item ? "selected" : ""}>${item}</option>`).join("")}
                    </select>
                </label>
                <label>Due date<input id="taskEditDeadline" type="date" value="${escapeTeamHtml(task.deadline || task.due_date || "")}"></label>
            </div>
            <div class="task-edit-actions">
                <button class="secondary" type="button" onclick="exitDashboardTaskEditMode()">Cancel</button>
                <button type="submit"><i class="fas fa-floppy-disk"></i>Save Changes</button>
            </div>
        </form>
    `;
}

function renderTaskEmptyState() {
    const detail = document.getElementById("task-detail-content");
    if (!detail) return;

    detail.innerHTML = `
        <div class="task-empty-state">
            <div class="task-empty-illustration" aria-hidden="true">
                <span></span><span></span><span></span>
            </div>
            <h2>Select a task to view details</h2>
            <p>Open a task from the inbox to see comments, attachments, history, and status controls.</p>
        </div>
    `;
}

function getSelectedDashboardTask() {
    if (!selectedDashboardTaskId) return null;
    return dashboardTaskCache.tasks.find(task => String(task.id) === String(selectedDashboardTaskId)) || null;
}

function selectDashboardTask(taskId) {
    const list = document.getElementById("all-tasks-list");
    if (list) {
        dashboardTaskInboxScrollTop = list.scrollTop;
        sessionStorage.setItem("taskflow.taskInboxScrollTop", String(dashboardTaskInboxScrollTop));
    }
    selectedDashboardTaskId = String(taskId || "");
    activeTaskId = selectedDashboardTaskId;
    dashboardTaskDetailOpen = true;
    dashboardTaskEditMode = false;
    sessionStorage.setItem("taskflow.selectedTaskId", selectedDashboardTaskId);
    renderDashboardTaskBoard();
}

function clearDashboardTaskSelection() {
    activeTaskId = null;
    dashboardTaskDetailOpen = false;
    dashboardTaskEditMode = false;
    renderDashboardTaskBoard();
    restoreDashboardTaskInboxScroll();
}

function restoreDashboardTaskInboxScroll() {
    if (dashboardTaskDetailOpen) return;
    const list = document.getElementById("all-tasks-list");
    if (!list || !dashboardTaskInboxScrollTop) return;
    requestAnimationFrame(() => {
        list.scrollTop = dashboardTaskInboxScrollTop;
    });
}

function handleTaskListItemKeydown(event, taskId) {
    if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectDashboardTask(taskId);
        return;
    }

    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;

    event.preventDefault();
    const items = Array.from(document.querySelectorAll(".task-list-item[data-task-id]"));
    const index = items.findIndex(item => String(item.dataset.taskId) === String(taskId));
    const nextIndex = event.key === "ArrowDown"
        ? Math.min(items.length - 1, index + 1)
        : Math.max(0, index - 1);
    items[nextIndex]?.focus();
}

function toggleDashboardTaskSelection(taskId, checked) {
    const key = String(taskId || "");
    if (!key) return;
    if (checked) {
        dashboardSelectedTaskIds.add(key);
    } else {
        dashboardSelectedTaskIds.delete(key);
    }
    updateTaskBulkState();
}

function updateTaskBulkState() {
    const count = document.getElementById("taskBulkCount");
    if (count) {
        const total = dashboardSelectedTaskIds.size;
        count.textContent = `${total} selected`;
    }
}

async function bulkCompleteSelectedTasks() {
    const ids = Array.from(dashboardSelectedTaskIds);
    if (!ids.length) {
        alert("Select tasks first");
        return;
    }

    for (const id of ids) {
        await updateDashboardTask(id, { status: "Completed" }, { silent: true });
    }

    dashboardSelectedTaskIds.clear();
    await loadAllTasks();
}

function isDashboardTaskStarred(taskId) {
    const starred = JSON.parse(localStorage.getItem("taskflow.starredTasks") || "[]");
    return starred.includes(String(taskId));
}

function toggleTaskStar(event, taskId) {
    event.stopPropagation();
    const key = String(taskId || "");
    const starred = new Set(JSON.parse(localStorage.getItem("taskflow.starredTasks") || "[]"));
    if (starred.has(key)) {
        starred.delete(key);
    } else {
        starred.add(key);
    }
    localStorage.setItem("taskflow.starredTasks", JSON.stringify(Array.from(starred)));
    renderDashboardTaskBoard();
}

function handleDashboardTaskFiltersChange() {
    dashboardTaskPage = 1;
    renderDashboardTaskBoard();
}

function dashboardTaskMatchesDueFilter(task, filter) {
    if (filter === "all") return true;
    const due = task.deadline || task.due_date;
    if (filter === "none") return !due;
    if (!due) return false;

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDate = new Date(String(due).length === 10 ? `${due}T00:00:00` : due);
    dueDate.setHours(0, 0, 0, 0);
    const diffDays = Math.round((dueDate - today) / 86400000);

    if (filter === "overdue") return diffDays < 0;
    if (filter === "today") return diffDays === 0;
    if (filter === "week") return diffDays >= 0 && diffDays <= 7;
    return true;
}

function compareDashboardTasks(a, b, sortValue) {
    if (sortValue === "title-asc") {
        return String(a.title || "").localeCompare(String(b.title || ""));
    }

    if (sortValue === "priority-desc") {
        const weight = { Urgent: 4, High: 3, Medium: 2, Low: 1 };
        return (weight[normalizeDashboardTaskPriority(b.priority)] || 0) - (weight[normalizeDashboardTaskPriority(a.priority)] || 0);
    }

    if (sortValue === "due-asc") {
        return getDashboardTaskDueTime(a) - getDashboardTaskDueTime(b);
    }

    return new Date(b.created_at || b.updated_at || 0) - new Date(a.created_at || a.updated_at || 0);
}

function getDashboardTaskDueTime(task) {
    const due = task.deadline || task.due_date;
    if (!due) return Number.MAX_SAFE_INTEGER;
    const date = new Date(String(due).length === 10 ? `${due}T00:00:00` : due);
    return Number.isNaN(date.getTime()) ? Number.MAX_SAFE_INTEGER : date.getTime();
}

function getTaskPreview(value) {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    return text.length > 88 ? `${text.slice(0, 88)}...` : text;
}

function renderTaskAvatarStack(assignments, users) {
    if (!assignments.length) return `<span class="task-avatar-empty">Unassigned</span>`;
    const visible = assignments.slice(0, 3);
    const extra = assignments.length - visible.length;
    return `
        ${visible.map(assignment => {
            const email = String(assignment.user_id || "Unassigned");
            const name = getUserDisplayName(email, users);
            return `<span class="task-avatar-mini" title="${escapeTeamHtml(email)}">${escapeTeamHtml(getAvatarInitial(name || email))}</span>`;
        }).join("")}
        ${extra > 0 ? `<span class="task-avatar-extra">+${extra}</span>` : ""}
    `;
}

function renderDashboardStatusControl(task, role, statusClass) {
    const status = normalizeMemberStatus(task.status);
    if (role === "user") {
        return renderMyStatusControl(task);
    }

    return `
        
        <span class="status-pill ${statusClass} task-detail-status-label">${escapeTeamHtml(status)}</span>
    `;
}

function renderTaskDetailAssignees(task) {
    const assignments = getTaskAssignments(task);
    if (!assignments.length) return `<p class="task-muted">Unassigned.</p>`;
    return `
        <div class="task-detail-assignees">
            ${assignments.map(assignment => {
                const email = String(assignment.user_id || "Unassigned");
                const name = getUserDisplayName(email, dashboardTaskCache.users);
                const status = normalizeMemberStatus(assignment.status);
                return `
                    <div class="task-detail-assignee">
                        <span class="task-avatar-mini">${escapeTeamHtml(getAvatarInitial(name || email))}</span>
                        <div>
                            <strong>${escapeTeamHtml(name)}</strong>
                            <small>${escapeTeamHtml(email)}</small>
                        </div>
                        <span class="member-status-badge ${memberStatusClass(status)}"><span class="member-status-dot"></span>${escapeTeamHtml(status)}</span>
                    </div>
                `;
            }).join("")}
        </div>
    `;
}

function renderTaskTimeline(task) {
    const items = [
        task.created_at ? { label: "Task created", time: task.created_at } : null,
        task.updated_at ? { label: "Last updated", time: task.updated_at } : null,
        normalizeMemberStatus(task.status) === "Completed" ? { label: "Marked complete", time: task.updated_at || task.deadline } : null
    ].filter(Boolean);

    return `
        <section class="task-detail-section">
            <h3>Activity Timeline</h3>
            <div class="task-timeline">
                ${items.length ? items.map(item => `
                    <div class="task-timeline-item">
                        <span></span>
                        <div><strong>${escapeTeamHtml(item.label)}</strong><small>${escapeTeamHtml(formatDateTime(item.time))}</small></div>
                    </div>
                `).join("") : `<p class="task-muted">No activity timeline yet.</p>`}
            </div>
        </section>
    `;
}

function renderTaskComments(task) {
    const comments = Array.isArray(task.comments) ? task.comments : [];
    return `
        <section class="task-detail-section">
            <h3>Comments</h3>
            <div class="task-comments">
                ${comments.length ? comments.map(comment => `
                    <article class="task-comment">
                        <span class="task-avatar-mini">${escapeTeamHtml(getAvatarInitial(comment.author_name || comment.author))}</span>
                        <div>
                            <strong>${escapeTeamHtml(comment.author_name || comment.author || "User")}</strong>
                            <p>${escapeTeamHtml(comment.content || "")}</p>
                            <small>${escapeTeamHtml(formatDateTime(comment.created_at))}</small>
                        </div>
                    </article>
                `).join("") : `<p class="task-muted">No comments yet.</p>`}
            </div>
            <div class="task-comment-form">
                <input id="task-comment-input" type="text" placeholder="Add a comment..." onkeydown="if(event.key === 'Enter') addTaskComment()">
                <button type="button" onclick="addTaskComment()"><i class="fas fa-paper-plane"></i>Add Comment</button>
            </div>
        </section>
    `;
}

function renderTaskHistory(task) {
    const history = Array.isArray(task.history) ? task.history : [];
    return `
        <section class="task-detail-section">
            <h3>Task History</h3>
            ${history.length ? `
                <div class="task-history-list">
                    ${history.map(item => `<div>${escapeTeamHtml(item.message || item.action || "")}<small>${escapeTeamHtml(formatDateTime(item.created_at || item.timestamp))}</small></div>`).join("")}
                </div>
            ` : `<p class="task-muted">No detailed history available.</p>`}
        </section>
    `;
}

function enterDashboardTaskEditMode() {
    dashboardTaskEditMode = true;
    renderDashboardTaskDetail();
}

function exitDashboardTaskEditMode() {
    dashboardTaskEditMode = false;
    renderDashboardTaskDetail();
}

async function saveDashboardTaskEdit(event, taskId) {
    event.preventDefault();
    const payload = {
        title: document.getElementById("taskEditTitle")?.value.trim(),
        description: document.getElementById("taskEditDescription")?.value.trim(),
        priority: document.getElementById("taskEditPriority")?.value,
        status: document.getElementById("taskEditStatus")?.value,
        deadline: document.getElementById("taskEditDeadline")?.value
    };

    if (!payload.title) {
        alert("Task title is required");
        return;
    }

    await updateDashboardTask(taskId, payload);
    dashboardTaskEditMode = false;
    await loadAllTasks();
}

async function markDashboardTaskComplete(taskId) {
    await updateStatus(taskId, "Completed");
}

async function updateDashboardTask(taskId, payload, options = {}) {
    const token = sessionStorage.getItem("token");
    const res = await fetch(`${BASE_URL}/tasks/${encodeURIComponent(taskId)}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify(payload)
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        alert(data.message || data.detail || "Unable to update task");
        return null;
    }

    if (!options.silent) {
        showNotification(data.message || "Task updated", "success", "Task Updated");
    }
    sendRealtimeMessage({ type: "client.task.updated", data: { task_id: taskId } });
    return data.task || null;
}

function normalizeDashboardTaskPriority(priority) {
    const normalized = String(priority || "Medium").trim().toLowerCase();
    if (normalized === "urgent") return "Urgent";
    if (normalized === "high") return "High";
    if (normalized === "low") return "Low";
    return "Medium";
}

function openDashboardTaskCreate() {
    setActiveMenu("dashboard");
    showView("dashboard-view");
    openCreate("task");
    const taskTitle = document.getElementById("task-title");
    if (taskTitle) taskTitle.focus();
}

function setDashboardTaskPage(page) {
    dashboardTaskPage = page;
    renderDashboardTaskBoard();
}

function renderDashboardTaskPagination(start, end, total, page, totalPages) {
    const footer = document.getElementById("dashboardTaskPagination");
    if (!footer) return;

    footer.innerHTML = `
        <span class="app-pagination-summary">${total ? `Showing ${start} to ${end} of ${total} tasks` : "Showing 0 tasks"}</span>
        <div class="task-pagination-controls app-pagination-controls">
            <button class="task-page-btn app-page-btn" type="button" onclick="setDashboardTaskPage(${page - 1})" ${page <= 1 ? "disabled" : ""} aria-label="Previous task page">
                <i class="fas fa-chevron-left"></i>
            </button>
            <span class="task-page-current app-page-current">${page}</span>
            <button class="task-page-btn app-page-btn" type="button" onclick="setDashboardTaskPage(${page + 1})" ${page >= totalPages ? "disabled" : ""} aria-label="Next task page">
                <i class="fas fa-chevron-right"></i>
            </button>
        </div>
    `;
}

function setProjectWorkspaceTaskPage(page) {
    projectWorkspaceTaskPage = page;
    loadProjectWorkspace();
}

function renderProjectWorkspacePagination(start, end, total, page, totalPages) {
    const footer = document.getElementById("projectTaskPagination");
    if (!footer) return;

    footer.innerHTML = `
        <span class="app-pagination-summary">${total ? `Showing ${start} to ${end} of ${total} tasks` : "Showing 0 tasks"}</span>
        <div class="task-pagination-controls app-pagination-controls">
            <button class="task-page-btn app-page-btn" type="button" onclick="setProjectWorkspaceTaskPage(${page - 1})" ${page <= 1 ? "disabled" : ""} aria-label="Previous project task page">
                <i class="fas fa-chevron-left"></i>
            </button>
            <span class="task-page-current app-page-current">${page}</span>
            <button class="task-page-btn app-page-btn" type="button" onclick="setProjectWorkspaceTaskPage(${page + 1})" ${page >= totalPages ? "disabled" : ""} aria-label="Next project task page">
                <i class="fas fa-chevron-right"></i>
            </button>
        </div>
    `;
}

// Load all tasks for user
async function loadAllTasks() {
    const role = sessionStorage.getItem("role");
    const email = sessionStorage.getItem("email");
    const token = sessionStorage.getItem("token");

    if (!role || !email || !token) return;

    try {
        renderDashboardTaskSkeleton();
        const [projectsRes, tasksRes, usersRes] = await Promise.all([
            fetch(`${BASE_URL}/projects`, {
                headers: { "Authorization": "Bearer " + token }
            }),
            fetch(`${BASE_URL}/tasks`, {
                headers: { "Authorization": "Bearer " + token }
            }),
            fetch(`${BASE_URL}/users`, {
                headers: { "Authorization": "Bearer " + token }
            })
        ]);

        const projects = await projectsRes.json();
        const tasks = await tasksRes.json();
        const users = await usersRes.json().catch(() => []);

        dashboardTaskCache = {
            projects: Array.isArray(projects) ? projects : [],
            tasks: Array.isArray(tasks) ? tasks : [],
            users: Array.isArray(users) ? users : []
        };

        const assignedHeader = document.getElementById("all-tasks-assigned-header");
        if (assignedHeader) {
            assignedHeader.textContent = role === "user" ? "Assigned By" : "Assigned Users & Status";
        }
        populateDashboardTaskFilters(dashboardTaskCache.projects);
        renderDashboardTaskBoard();
    } catch (error) {
        console.error("Failed to load tasks", error);
        const list = document.getElementById("all-tasks-list");
        if (list) {
            list.innerHTML = `<div class="task-inbox-empty-list"><i class="fas fa-triangle-exclamation"></i><strong>Unable to load tasks</strong><span>Please refresh and try again.</span></div>`;
        }
    }
}

window.addEventListener("load", () => {
    const role = sessionStorage.getItem("role");

    if (role === "user") {
        // Hide header
        const header = document.getElementById("task-action-header");
        if (header) header.style.display = "none";

        // Hide all action column cells
        document.querySelectorAll("#all-tasks-list td:last-child").forEach(td => {
            td.style.display = "none";
        });
    }
});

// Load team members
async function loadTeamMembers() {
    const role = sessionStorage.getItem("role");
    const email = sessionStorage.getItem("email");
    const token = sessionStorage.getItem("token");

    if (!role || !email || !token) return;

    try {
        const workspaceRes = await fetch(`${BASE_URL}/projects/team-workspace`, {
            headers: { "Authorization": "Bearer " + token }
        });

        const workspace = await workspaceRes.json();
        const projects = workspace.projects;
        const tasks = workspace.tasks;
        const usersPayload = workspace.users;
        const users = Array.isArray(usersPayload) ? usersPayload : [];

        const teamList = document.getElementById("team-members-list");
        if (!teamList) return;

        if (!Array.isArray(projects) || !Array.isArray(tasks)) {
            teamList.innerHTML = `<div class="team-empty-state">Unable to load team members</div>`;
            return;
        }

        teamWorkspaceCache = { projects, tasks, users };
        allUsersCache = Array.isArray(users) ? users.slice() : [];
        teamMemberCache = users.slice();
        populateTeamProjectFilter(projects);
        renderTeamWorkspace();
    } catch (error) {
        console.error("Failed to load team members", error);
    }
}

function populateTeamProjectFilter(projects) {
    const filter = document.getElementById("teamProjectFilter");
    if (!filter) return;

    const role = sessionStorage.getItem("role");
    const userEmail = (sessionStorage.getItem("email") || "").trim().toLowerCase();
    const { tasks } = teamWorkspaceCache;

    const filteredProjects = role === "user"
        ? projects.filter(project => userBelongsToTeamProject(project, tasks, userEmail))
        : projects;

    const currentValue = filter.value || "all";
    filter.innerHTML = `<option value="all">All Projects</option>`;

    filteredProjects.forEach(project => {
        const option = document.createElement("option");
        option.value = String(project.id);
        option.textContent = project.name || "Untitled Project";
        filter.appendChild(option);
    });

    filter.value = Array.from(filter.options).some(option => option.value === currentValue)
        ? currentValue
        : "all";
}

function isTeamProjectExpanded(projectId, defaultExpanded = false) {
    const key = String(projectId);
    if (Object.prototype.hasOwnProperty.call(expandedTeamProjects, key)) {
        return expandedTeamProjects[key];
    }
    return defaultExpanded;
}

function toggleTeamProject(projectId) {
    const key = String(projectId);
    expandedTeamProjects[key] = !isTeamProjectExpanded(key, true);
    renderTeamWorkspace();
}

function renderTeamWorkspace() {
    const list = document.getElementById("team-members-list");
    if (!list) return;

    const role = sessionStorage.getItem("role");
    const newProjectBtn = document.querySelector(".team-new-project-btn");
    if (newProjectBtn) {
        newProjectBtn.style.display = role === "manager" || role === "admin" ? "" : "none";
    }

    const query = (document.getElementById("teamSearchInput")?.value || "").trim().toLowerCase();
    const selectedProject = document.getElementById("teamProjectFilter")?.value || "all";
    const { projects, tasks, users } = teamWorkspaceCache;

    const userMap = new Map(
        users.map(user => [String(user.email || "").trim().toLowerCase(), user])
    );

    const userEmail = (sessionStorage.getItem("email") || "").trim().toLowerCase();

    let visibleProjects = projects.filter(project => {
        const matchesFilter =
            selectedProject === "all" || String(project.id) === String(selectedProject);

        if (role === "user") {
            return matchesFilter && userBelongsToTeamProject(project, tasks, userEmail);
        }

        return matchesFilter;
    });

    const sections = visibleProjects.map((project, index) => {

        const allProjectTasks = tasks.filter(task =>
            String(task.project_id) === String(project.id)
        );
        let projectTasks = allProjectTasks;

        // Search filter
        if (query) {
            projectTasks = projectTasks.filter(task => {
                const assignments = getTaskAssignments(task);
                return [
                    project.name,
                    task.title,
                    normalizeTeamStatus(task.status),
                    ...assignments.flatMap(assignment => {
                        const member = userMap.get(String(assignment.user_id || "").trim().toLowerCase());
                        return [assignment.user_id, member?.username, normalizeTeamStatus(assignment.status)];
                    })
                ].some(value => String(value || "").toLowerCase().includes(query));
            });
        }

        const projectNameMatches = !query || String(project.name || "").toLowerCase().includes(query);
        const memberRows = buildTeamMemberRows(projectTasks, userMap);
        const memberCount = buildTeamMemberRows(allProjectTasks, userMap).length;
        const uniqueMembers = Array.from(
            new Map(memberRows.map(member => [String(member.email || "").trim().toLowerCase(), member])).values()
        );
        const forceExpanded = selectedProject !== "all" || Boolean(query);
        const isExpanded = isTeamProjectExpanded(project.id, forceExpanded || index === 0);

        if (!projectNameMatches && !projectTasks.length) return "";

        return `
            <section class="team-project-card ${isExpanded ? "expanded" : "collapsed"}">
                <button
                    class="team-project-head"
                    type="button"
                    onclick="toggleTeamProject('${project.id}')"
                    aria-expanded="${isExpanded ? "true" : "false"}"
                >
                    <div class="team-project-title">
                        <span class="team-project-icon ${teamProjectColorClass(index)}">
                            <i class="fas fa-folder"></i>
                        </span>
                        <h3>${escapeTeamHtml(project.name || "Untitled Project")}</h3>
                        <span class="team-member-count">${memberCount} Member${memberCount === 1 ? "" : "s"}</span>
                    </div>
                    <span class="team-project-toggle" aria-hidden="true">
                        <i class="fas fa-chevron-down"></i>
                    </span>
                </button>

                <div class="team-table-wrap ${isExpanded ? "" : "hidden"}">
                    <table class="team-table">
                        <thead>
                            <tr>
                                <th>Member</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                       <tbody>
                        ${
                            uniqueMembers.length
                                ? uniqueMembers.map(member => renderTeamMemberRow(member)).join("")
                                : `
                                <tr>
                                    <td colspan="2" class="team-empty-row">
                                        No members yet
                                    </td>
                                </tr>
                                `
                        }
                    </tbody>
                    </table>
                

                ${role === "manager" ? `
                    <button class="team-add-member-btn" type="button" onclick="openTeamAddMember('${project.id}')">
                        <i class="fas fa-plus"></i>
                        <span>Add Member</span>
                    </button>
                ` : ""}
                </div>
            </section>
        `;
    }).filter(Boolean);

    list.innerHTML = sections.length
        ? sections.join("")
        : `<div class="team-empty-state">No members found</div>`;
}

function userBelongsToTeamProject(project, tasks, userEmail) {
    return tasks.some(task =>
        String(task.project_id) === String(project.id) &&
        userIsAssignedToTask(task, userEmail)
    );
}

function buildTeamMemberRows(tasks, userMap) {
    const members = new Map();

    tasks.forEach(task => {
        getTaskAssignments(task).forEach(assignment => {
            const email = String(assignment.user_id || "").trim().toLowerCase();
            if (!email || members.has(email)) return;

            const member = userMap.get(email) || {};
            const name = member.username || assignment.user_id || email;
            members.set(email, {
                email: assignment.user_id || email,
                name
            });
        });
    });

    return Array.from(members.values()).sort((a, b) => a.name.localeCompare(b.name));
}

function renderTeamMemberRow(member) {
    return `
        <tr>
            <td>
                <span class="team-member-cell">
                    <span class="team-avatar">${escapeTeamHtml(member.name.charAt(0).toUpperCase() || "?")}</span>
                    <span>${escapeTeamHtml(member.name)}</span>
                </span>
            </td>
            <td>${escapeTeamHtml(member.email || "Unassigned")}</td>
        </tr>
    `;
}

function renderTeamTaskRow(task, userMap) {
    return `
        <tr>
            <td>${escapeTeamHtml(task.title || "Untitled Task")}</td>
            <td>${renderMemberStatusBadges(task)}</td>
        </tr>
    `;
}

function normalizeTeamStatus(status) {
    const value = String(status || "Pending").trim().toLowerCase();
    if (value === "done" || value === "completed") return "Completed";
    if (value === "in progress" || value === "progress") return "In Progress";
    if (value === "on hold" || value === "hold") return "On Hold";
    if (value === "planning" || value === "planned") return "Planning";
    return "Pending";
}

function teamStatusClass(status) {
    return String(status || "").toLowerCase().replace(/\s+/g, "-");
}

function teamProjectColorClass(index) {
    return ["blue", "pink", "green"][index % 3];
}

function openTeamAddMember(projectId) {
    sessionStorage.setItem("selectedProjectId", projectId);
    setActiveMenu("overview");
    showView("dashboard-view");
    openCreate("task");
    const projectSelect = document.getElementById("project-select");
    if (projectSelect) projectSelect.value = projectId;
}

function openTeamCreateProject() {
    setActiveMenu("overview");
    showView("dashboard-view");
    openCreate("project");
    const projectName = document.getElementById("project-name");
    if (projectName) projectName.focus();
}

function escapeTeamHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[char]));
}

let dashboardCalendarTasks = [];
let dashboardCalendarMonth = new Date().getMonth();
let dashboardCalendarYear = new Date().getFullYear();

function initializeCalendar() {
    const role = sessionStorage.getItem("role");
    const email = sessionStorage.getItem("email");
    const token = sessionStorage.getItem("token");

    if (!role || !email || !token) return;

    fetch(`${BASE_URL}/tasks`, {
        headers: { "Authorization": "Bearer " + token }
    })
        .then(res => res.json())
        .then(tasks => {
            dashboardCalendarTasks = tasks || [];
            renderDashboardCalendar();
            renderDashboardYearOptions();
        })
        .catch(error => console.error("Failed to load calendar", error));
}

function renderDashboardCalendar() {
    const calendarMonthYear = document.getElementById("calendar-month-year");
    const calendarDiv = document.getElementById("calendar");

    if (!calendarMonthYear || !calendarDiv) return;

    const currentMonth = new Date(dashboardCalendarYear, dashboardCalendarMonth);
    calendarMonthYear.textContent = currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' });
    calendarDiv.innerHTML = generateCalendarDays(dashboardCalendarTasks, dashboardCalendarMonth, dashboardCalendarYear);
}

function renderDashboardYearOptions() {
    const yearSelect = document.getElementById("calendar-year-select");

    if (!yearSelect) return;

    const currentYear = new Date().getFullYear();
    const startYear = currentYear - 50;
    const endYear = currentYear + 50;
    yearSelect.innerHTML = '';

    for (let year = startYear; year <= endYear; year++) {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearSelect.appendChild(option);
    }

    yearSelect.value = dashboardCalendarYear;
}

function changeCalendarMonth(offset) {
    dashboardCalendarMonth += offset;

    if (dashboardCalendarMonth < 0) {
        dashboardCalendarMonth = 11;
        dashboardCalendarYear -= 1;
    }
    if (dashboardCalendarMonth > 11) {
        dashboardCalendarMonth = 0;
        dashboardCalendarYear += 1;
    }

    renderDashboardYearOptions();
    renderDashboardCalendar();
}

function onCalendarYearChange(event) {
    const selectedYear = parseInt(event.target.value, 10);
    if (!Number.isNaN(selectedYear)) {
        dashboardCalendarYear = selectedYear;
        renderDashboardCalendar();
    }
}

function generateCalendarDays(tasks, month, year) {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    let html = '';
    const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    weekDays.forEach(day => {
        html += `<div class="calendar-weekday">${day}</div>`;
    });

    for (let i = 0; i < startingDayOfWeek; i++) {
        html += '<div class="calendar-day empty"></div>';
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const tasksOnDay = tasks.filter(t => t.deadline === dateStr);
        const hasTasks = tasksOnDay.length > 0;
        const today = new Date();
        const isToday = day === today.getDate() && month === today.getMonth() && year === today.getFullYear();

        html += `
            <div class="calendar-day ${hasTasks ? 'has-tasks' : ''} ${isToday ? 'today' : ''}">
                <div class="date-number">${day}</div>
                ${hasTasks ? `<div class="task-count">${tasksOnDay.length} task${tasksOnDay.length > 1 ? 's' : ''}</div>` : '<div class="task-count">No tasks</div>'}
            </div>
        `;
    }

    return html;
}

async function loadDashboardSummary() {
    const role = sessionStorage.getItem("role");
    const email = sessionStorage.getItem("email");
    const token = sessionStorage.getItem("token");

    try {
        const [projectsRes, tasksRes] = await Promise.all([
            fetch(`${BASE_URL}/projects`, {
                headers: { "Authorization": "Bearer " + token }
            }),
            fetch(`${BASE_URL}/tasks`, {
                headers: { "Authorization": "Bearer " + token }
            })
        ]);

        const projects = await projectsRes.json();
        const tasks = await tasksRes.json();

        let filteredProjects = projects;
        let filteredTasks = tasks;

        if (role === "user") {
            filteredTasks = tasks.filter(t => userIsAssignedToTask(t, email));

            const projectIds = new Set(filteredTasks.map(t => t.project_id));

            filteredProjects = projects.filter(p => projectIds.has(p.id));
        }

        renderSummary(filteredProjects, filteredTasks);

    } catch (error) {
        console.error("Failed to load dashboard summary", error);
    }
}

function renderSummary(projects, tasks) {
    const totalProjects = document.getElementById("total-projects");
    const totalTasks = document.getElementById("total-tasks");
    const completionRate = document.getElementById("completion-rate");

    const completedTasks = tasks.filter(t => normalizeMemberStatus(t.status) === "Completed").length;
    const total = tasks.length;

    const percent = total === 0 ? 0 : Math.round((completedTasks / total) * 100);

    totalProjects.textContent = projects.length;
    totalTasks.textContent = tasks.length;
    completionRate.textContent = percent + "%";
}

async function loadProjectWorkspace() {
    const projectId = sessionStorage.getItem("selectedProjectId");
    const role = sessionStorage.getItem("role");
    const email = sessionStorage.getItem("email");

    if (!projectId || !role || !email) {
        return;
    }

    if (role !== "manager") {
        const actionHeader = document.getElementById("action-header");
        if (actionHeader) actionHeader.style.display = "none";
    }
    
    try {
        const token = sessionStorage.getItem("token");
        const [projectsRes, usersRes] = await Promise.all([
            fetch(`${BASE_URL}/projects`, {
                headers: { "Authorization": "Bearer " + token }
            }),
            fetch(`${BASE_URL}/users`, {
                headers: { "Authorization": "Bearer " + token }
            })
        ]);
        const projects = await projectsRes.json();
        const users = await usersRes.json().catch(() => []);
        const project = projects.find(p => String(p.id) === String(projectId));
        document.getElementById("project-title").innerText = project?.name || "Project";

        // Load project tasks
        const tasksRes = await fetch(`${BASE_URL}/tasks`, {
            headers: { "Authorization": "Bearer " + token }
        });
        const tasks = await tasksRes.json();
        
        const list = document.getElementById("task-list");
        list.innerHTML = "";
        const assignedHeader = document.getElementById("workspace-assigned-header");
        if (assignedHeader) {
            assignedHeader.textContent = role === "user" ? "Assigned By" : "Assigned Users & Status";
        }

        const projectTasks = tasks.filter(t =>
            String(t.project_id) === String(projectId)
        );

        if (projectTasks.length === 0) {
            list.innerHTML = `
                <tr>
                    <td colspan="6">No tasks available</td>
                </tr>
            `;
            renderProjectWorkspacePagination(0, 0, 0, 1, 1);
            return;
        }

        const totalPages = Math.max(Math.ceil(projectTasks.length / projectWorkspaceTaskPageSize), 1);
        projectWorkspaceTaskPage = Math.min(Math.max(projectWorkspaceTaskPage, 1), totalPages);
        const startIndex = (projectWorkspaceTaskPage - 1) * projectWorkspaceTaskPageSize;
        const pageTasks = projectTasks.slice(startIndex, startIndex + projectWorkspaceTaskPageSize);

        pageTasks.forEach(t => {
            const row = document.createElement("tr");
            const assignedDisplay = role === "user" ? getTaskAssignedBy(t, project) : renderTaskAssigneeStatusList(t, Array.isArray(users) ? users : []);
            const statusClass = memberStatusClass(t.status);
            const priority = normalizeDashboardTaskPriority(t.priority);
            const priorityClass = priority.toLowerCase().replace(/\s+/g, "-");

            row.innerHTML = `
                <td >
                    <div>
                        <span >${escapeTeamHtml(t.title || "Untitled Task")}</span>
                        ${renderTaskAttachments(t)}
                    </div>
                </td>
                <td><span class="task-priority-pill ${priorityClass}">${escapeTeamHtml(priority)}</span></td>
                <td>${assignedDisplay || "Unknown"}</td>
                <td>${formatDeadlineDate(t.deadline)}</td>

                ${
                    role === "user"
                    ? `
                    <td>
                        ${renderMyStatusControl(t)}
                    </td>
                    `
                    : `
                    <td>
                        <span class="status ${statusClass}">${normalizeMemberStatus(t.status)}</span>
                    </td>
                    `
                }

                ${
                    role === "manager"
                    ? `
                    <td>
                        <button class="delete-btn" type="button" onclick="deleteTask('${t.id}')">Delete</button>
                    </td>
                    `
                    : ""
                }
            `;

            list.appendChild(row);
        });
        renderProjectWorkspacePagination(startIndex + 1, startIndex + pageTasks.length, projectTasks.length, projectWorkspaceTaskPage, totalPages);

    } catch (error) {
        console.error("Failed to load project workspace", error);
    }
}

async function addTaskComment() {
    const token = sessionStorage.getItem("token");
    const input = document.getElementById("task-comment-input");
    if (!activeTaskId || !input) return;

    const content = input.value.trim();
    if (!content) {
        alert("Write a comment first");
        return;
    }

    const res = await fetch(`${BASE_URL}/tasks/${activeTaskId}/comments`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify({ content })
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        alert(data.detail || data.message || "Unable to post comment");
        return;
    }

    input.value = "";
    if (data.task) {
        dashboardTaskCache.tasks = dashboardTaskCache.tasks.map(task =>
            String(task.id) === String(activeTaskId) ? data.task : task
        );
        renderDashboardTaskBoard();
    } else {
        await loadTaskComments(activeTaskId);
    }
}

async function loadTaskComments(taskId) {
    const token = sessionStorage.getItem("token");
    if (!token || !taskId) return;

    const res = await fetch(`${BASE_URL}/tasks`, {
        headers: { "Authorization": "Bearer " + token }
    });
    const tasks = await res.json().catch(() => []);
    if (!Array.isArray(tasks)) return;

    dashboardTaskCache.tasks = tasks;
    selectedDashboardTaskId = String(taskId);
    activeTaskId = String(taskId);
    renderDashboardTaskBoard();
}

function showProjectWorkspace() {
    hideAllViews();
    document.getElementById('project-workspace-view').classList.remove('hidden');
}

let activityExportState = {
    format: "excel"
};

function exportActivityLog() {
    openActivityExportModal();
}

function openActivityExportModal() {
    const modal = document.getElementById("activity-export-modal");
    if (!modal) return;

    setDefaultActivityExportDates();
    syncActivityExportModalUI();
    modal.classList.remove("hidden");
    document.body.classList.add("export-modal-open");
}

function closeActivityExportModal() {
    const modal = document.getElementById("activity-export-modal");
    if (!modal) return;

    modal.classList.add("hidden");
    document.body.classList.remove("export-modal-open");
}

function setDefaultActivityExportDates() {
    const startInput = document.getElementById("activity-export-start-date");
    const endInput = document.getElementById("activity-export-end-date");
    if (!startInput || !endInput || startInput.value || endInput.value) return;

    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - 6);
    startInput.value = toDateInputValue(start);
    endInput.value = toDateInputValue(end);
}

function toDateInputValue(date) {
    return [
        date.getFullYear(),
        String(date.getMonth() + 1).padStart(2, "0"),
        String(date.getDate()).padStart(2, "0")
    ].join("-");
}

function selectActivityExportFormat(format) {
    activityExportState.format = format;
    syncActivityExportModalUI();
}

function syncActivityExportModalUI() {
    document.querySelectorAll("[data-activity-export-format]").forEach(card => {
        card.classList.toggle("selected", card.dataset.activityExportFormat === activityExportState.format);
    });
}

async function confirmActivityExport() {
    const token = sessionStorage.getItem("token");
    const startDate = document.getElementById("activity-export-start-date")?.value || "";
    const endDate = document.getElementById("activity-export-end-date")?.value || "";
    const includeDetails = document.getElementById("activity-export-detailed")?.checked ?? true;

    if (startDate && endDate && startDate > endDate) {
        alert("Start date cannot be after end date.");
        return;
    }

    try {
        const res = await fetch(`${BASE_URL}/activities`, {
            headers: { "Authorization": "Bearer " + token }
        });

        if (!res.ok) {
            const error = await res.json().catch(() => ({}));
            alert(error.message || error.detail || "Failed to export activity log.");
            return;
        }

        const logs = await res.json();
        const filteredLogs = filterActivityLogsByDate(Array.isArray(logs) ? logs : [], startDate, endDate);

        if (!filteredLogs.length) {
            alert("No activity records found for the selected date range.");
            return;
        }

        downloadActivityExport(filteredLogs, {
            format: activityExportState.format,
            startDate,
            endDate,
            includeDetails
        });
        closeActivityExportModal();
    } catch (error) {
        console.error(error);
        alert("Failed to export activity log.");
    }
}

function filterActivityLogsByDate(logs, startDate, endDate) {
    const start = parseReportDate(startDate);
    const end = parseReportDate(endDate, true);

    if (!start && !end) return logs;

    return logs.filter(log => {
        if (!log.timestamp) return false;
        const date = new Date(log.timestamp);
        if (Number.isNaN(date.getTime())) return false;
        if (start && date < start) return false;
        if (end && date > end) return false;
        return true;
    });
}

function formatActivityTime(timestamp) {

    const date = new Date(timestamp);

    return date.toLocaleString("en-IN", {

        timeZone: "Asia/Kolkata",

        day: "2-digit",

        month: "short",

        year: "numeric",

        hour: "2-digit",

        minute: "2-digit",

        second: "2-digit",

        hour12: true
    });
}

function formatDeadlineDate(value) {
    if (!value) return "N/A";

    const date = String(value).length === 10
        ? new Date(`${value}T00:00:00`)
        : new Date(value);

    if (Number.isNaN(date.getTime())) return value;

    return date.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    }).replace(/ /g, "-");
}

function downloadActivityExport(logs, options) {
    const rows = buildActivityExportRows(logs, options.includeDetails);
    const format = options.format || "csv";
    const rangeLabel = options.startDate || options.endDate ? `-${options.startDate || "start"}-to-${options.endDate || "end"}` : "";
    const filename = `taskflow-activity-log${rangeLabel}`;

    if (format === "pdf") {
        downloadActivityPdf(rows, filename);
        return;
    }

    if (format === "excel" && window.XLSX) {
        downloadActivityExcel(rows, filename);
        return;
    }

    const csv = rows.map(row => row.map(csvEscape).join(",")).join("\n");
    const mimeType = "text/csv;charset=utf-8;";
    const blob = new Blob([csv], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");

    anchor.href = url;
    anchor.download = `${filename}.csv`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
}

function downloadActivityPdf(rows, filename) {
    if (!window.jspdf?.jsPDF) {
        alert("PDF library is not loaded. Please refresh and try again.");
        return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF("p", "mm", "a4");
    let currentY = 18;
    let headers = [];
    let body = [];

    doc.setFontSize(18);
    doc.text("TaskFlow Activity Log", 14, currentY);
    currentY += 8;

    const flushTable = () => {
        if (!headers.length) return;

        doc.autoTable({
            startY: currentY,
            head: [headers],
            body,
            theme: "grid",
            styles: {
                fontSize: 8,
                cellPadding: 2,
                overflow: "linebreak"
            },
            headStyles: {
                fillColor: [47, 123, 255]
            },
            margin: { left: 10, right: 10 }
        });

        currentY = doc.lastAutoTable.finalY + 8;
        headers = [];
        body = [];
    };

    rows.forEach(row => {
        if (!row.length) return;

        if (row.length === 1) {
            flushTable();
            doc.setFontSize(13);
            doc.text(String(row[0]), 14, currentY);
            currentY += 7;
            return;
        }

        if (row.length === 2 && row[0] === "Exported At") {
            doc.setFontSize(10);
            doc.text(`Exported At: ${row[1]}`, 14, currentY);
            currentY += 8;
            return;
        }

        if (!headers.length) {
            headers = row;
            return;
        }

        body.push(row);
    });

    flushTable();
    doc.save(`${filename}.pdf`);
}

function downloadActivityExcel(rows, filename) {
    const worksheet = XLSX.utils.aoa_to_sheet(rows);
    worksheet["!cols"] = [
        { wch: 26 },
        { wch: 34 },
        { wch: 24 },
        { wch: 16 },
        { wch: 22 },
        { wch: 28 },
        { wch: 42 }
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Activity Log");
    XLSX.writeFile(workbook, `${filename}.xlsx`);
}

function buildActivityExportRows(logs, includeDetails) {
    const rows = [
        ["TaskFlow Activity Log"],
        ["Exported At", formatDateTime(new Date().toISOString())],
        [],
        includeDetails
            ? ["Timestamp", "User Email", "User Name", "Role", "Action", "Target", "Details"]
            : ["Timestamp", "User", "Action", "Details"]
    ];

    logs.forEach(log => {
        if (includeDetails) {
            rows.push([
                formatDateTime(log.timestamp),
                log.user_email || "",
                log.username || "",
                log.role || "",
                log.action || "",
                log.target || "",
                log.details || ""
            ]);
            return;
        }

        rows.push([
            formatDateTime(log.timestamp),
            log.user_email || log.username || "",
            log.action || "",
            [log.target, log.details].filter(Boolean).join(" - ")
        ]);
    });

    return rows;
}

let reportState = {
    projects: [],
    tasks: [],
    filteredProjects: [],
    filteredTasks: [],
    startDate: "",
    endDate: ""
};

let exportModalState = {
    sections: new Set(["projects", "overview", "tasks", "team"]),
    format: "excel"
};

let showAllProjects = false;
let showAllTeam = false;

function applyDashboardRoleVisibility() {
    const role = sessionStorage.getItem("role");
    const isUser = role === "user";
    const isManager = role === "manager";
    const activityMenu = document.querySelector('[data-sidebar="activity-log"]');
    const reportMenu = document.querySelector('[data-sidebar="report"]');
    const teamMenu = document.querySelector('[data-sidebar="team"]');
    const activityExportCard = document.querySelector('[data-export-section="activity"]');
    const projectSection = document.getElementById("project-section");
    const uploadBtn = document.getElementById("uploadBtn");
    const fileInput = document.getElementById("file-input");

    if (activityMenu) {
        activityMenu.style.display = isUser ? "none" : "";
    }

    if (reportMenu) {
        reportMenu.style.display = isUser ? "none" : "";
    }

    if (teamMenu) {
        teamMenu.style.display = "";
    }

    if (activityExportCard) {
        activityExportCard.style.display = isUser ? "none" : "";
    }

    if (projectSection) {
        projectSection.style.display = isManager || isUser ? "none" : "";
    }

    document.querySelectorAll("#taskAddButton, #dashboardHeaderTaskAddButton").forEach((button) => {
        button.style.display = isUser ? "none" : "";
    });

    if (uploadBtn) {
        uploadBtn.style.display = isUser ? "none" : "";
    }

    if (fileInput) {
        fileInput.disabled = isUser;
    }

    if (isUser) {
        exportModalState.sections.delete("activity");
    }
}

function normalizeReportStatus(status) {
    const value = String(status || "").trim().toLowerCase();
    if (value === "completed" || value === "done") return "done";
    if (value === "in progress" || value === "progress") return "in progress";
    return "pending";
}

function getReportDateFilters() {
    const startInput = document.getElementById("report-start-date");
    const endInput = document.getElementById("report-end-date");
    const startDate = startInput?.value || "";
    const endDate = endInput?.value || "";

    if (startDate && endDate && startDate > endDate) {
        if (endInput) endInput.value = startDate;
        return { startDate, endDate: startDate };
    }

    return { startDate, endDate };
}

function formatReportRangeDate(value) {
    if (!value) return "";

    const date = new Date(`${value}T00:00:00`);
    if (Number.isNaN(date.getTime())) return "";

    return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric"
    });
}

function formatReportChartDate(value) {
    if (!value || value === "No date") return value || "No date";
    const date = new Date(value.length === 10 ? `${value}T00:00:00` : value);
    if (Number.isNaN(date.getTime())) return value;

    return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric"
    });
}

function formatProjectChartLabel(name) {
    const words = String(name || "Untitled").split(" ").filter(Boolean);
    if (words.length <= 2) return words.join(" ");

    const midpoint = Math.ceil(words.length / 2);
    return [
        words.slice(0, midpoint).join(" "),
        words.slice(midpoint).join(" ")
    ];
}

function updateReportDateLabel() {
    const { startDate, endDate } = getReportDateFilters();
    const label = document.getElementById("report-date-label");
    if (!label) return;

    if (startDate && endDate) {
        const start = new Date(`${startDate}T00:00:00`);
        const end = new Date(`${endDate}T00:00:00`);
        const sameYear = start.getFullYear() === end.getFullYear();
        const startText = start.toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: sameYear ? undefined : "numeric"
        });
        const endText = end.toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric"
        });
        label.textContent = `${startText} - ${endText}`;
        return;
    }

    if (startDate) {
        label.textContent = `From ${formatReportRangeDate(startDate)}`;
        return;
    }

    if (endDate) {
        label.textContent = `Until ${formatReportRangeDate(endDate)}`;
        return;
    }

    label.textContent = "All dates";
}

function toggleReportDatePicker(event) {
    if (event) event.stopPropagation();
    const popover = document.getElementById("report-date-popover");
    if (popover) popover.classList.toggle("hidden");
}

function onReportDateChange() {
    updateReportDateLabel();
    loadReports();
}

function clearReportDateRange() {
    const startInput = document.getElementById("report-start-date");
    const endInput = document.getElementById("report-end-date");
    if (startInput) startInput.value = "";
    if (endInput) endInput.value = "";
    updateReportDateLabel();
    loadReports();
}

window.addEventListener("click", event => {
    const popover = document.getElementById("report-date-popover");
    const dateControl = document.querySelector(".report-date-control");
    if (popover && dateControl && !popover.classList.contains("hidden") && !dateControl.contains(event.target)) {
        popover.classList.add("hidden");
    }
});

function parseReportDate(value, endOfDay = false) {
    if (!value) return null;

    const date = new Date(`${value}T${endOfDay ? "23:59:59" : "00:00:00"}`);
    return Number.isNaN(date.getTime()) ? null : date;
}

function getTaskReportDate(task) {
    const value = task.deadline || task.created_at || task.updated_at || "";
    if (!value) return null;

    const date = value.length === 10 ? new Date(`${value}T00:00:00`) : new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
}

function filterReportTasksByDate(tasks, startDate, endDate) {
    const start = parseReportDate(startDate);
    const end = parseReportDate(endDate, true);

    if (!start && !end) return tasks;

    return tasks.filter(task => {
        const taskDate = getTaskReportDate(task);
        if (!taskDate) return false;
        if (start && taskDate < start) return false;
        if (end && taskDate > end) return false;
        return true;
    });
}

async function loadReports() {
    const token = sessionStorage.getItem("token");
    const role = sessionStorage.getItem("role");
    const email = (sessionStorage.getItem("email") || "").trim().toLowerCase();

    try {
        const [projectsRes, tasksRes] = await Promise.all([
            fetch(`${BASE_URL}/projects`, {
                headers: { Authorization: "Bearer " + token }
            }),
            fetch(`${BASE_URL}/tasks`, {
                headers: { Authorization: "Bearer " + token }
            })
        ]);

        if (!projectsRes.ok || !tasksRes.ok) {
            throw new Error("Unable to load report data");
        }

        let projects = await projectsRes.json();
        let tasks = await tasksRes.json();

        if (!Array.isArray(projects)) projects = [];
        if (!Array.isArray(tasks)) tasks = [];

        if (role === "user") {
            tasks = tasks.filter(t => userIsAssignedToTask(t, email));

            const projectIds = new Set(tasks.map(t => String(t.project_id)));
            projects = projects.filter(p => projectIds.has(String(p.id)));
        }

        const { startDate, endDate } = getReportDateFilters();
        const filteredTasks = filterReportTasksByDate(tasks, startDate, endDate);
        const isDateFiltered = Boolean(startDate || endDate);
        const filteredProjectIds = new Set(filteredTasks.map(t => String(t.project_id)));
        const filteredProjects = isDateFiltered
            ? projects.filter(p => filteredProjectIds.has(String(p.id)))
            : projects;

        reportState = {
            projects,
            tasks,
            filteredProjects,
            filteredTasks,
            startDate,
            endDate
        };

        const totalProjects = filteredProjects.length;
        const totalTasks = filteredTasks.length;

        const completed = filteredTasks.filter(t => normalizeReportStatus(t.status) === "done").length;
        const inProgress = filteredTasks.filter(t => normalizeReportStatus(t.status) === "in progress").length;

        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const overdue = filteredTasks.filter(t =>
            t.deadline && new Date(`${t.deadline}T00:00:00`) < today && normalizeReportStatus(t.status) !== "done"
        ).length;

        const completedPercent = totalTasks ? ((completed / totalTasks) * 100).toFixed(0) : 0;
        const progressPercent = totalTasks ? ((inProgress / totalTasks) * 100).toFixed(0) : 0;
        const overduePercent = totalTasks ? ((overdue / totalTasks) * 100).toFixed(0) : 0;

        document.getElementById("report-total-projects").textContent = totalProjects;
        document.getElementById("report-total-tasks").textContent = totalTasks;
        document.getElementById("report-completed-tasks").textContent = completed;
        document.getElementById("report-inprogress-tasks").textContent = inProgress;
        document.getElementById("report-overdue-tasks").textContent = overdue;

        document.getElementById("report-completed-percent").textContent = completedPercent + "% of total tasks";
        document.getElementById("report-progress-percent").textContent = progressPercent + "% of total tasks";
        document.getElementById("report-overdue-percent").textContent = overduePercent + "% of total tasks";

        updateReportDateLabel();
        renderCharts(filteredProjects, filteredTasks, completed, inProgress, overdue);
        renderProjectSummary(filteredProjects, filteredTasks);
        renderTeamSummary(filteredTasks);

        const projectBtn = document.getElementById("view-all-projects");
        const teamBtn = document.getElementById("view-team-report");

        if (projectBtn) {
            projectBtn.onclick = (e) => {
                e.preventDefault();

                showAllProjects = !showAllProjects;

                renderProjectSummary(reportState.filteredProjects, reportState.filteredTasks);

                projectBtn.textContent = showAllProjects 
                    ? "Show less" 
                    : "View all projects";
            };
        }

        if (teamBtn) {
            teamBtn.onclick = (e) => {
                e.preventDefault();

                showAllTeam = !showAllTeam;

                renderTeamSummary(reportState.filteredTasks);

                teamBtn.textContent = showAllTeam 
                    ? "Show less" 
                    : "View full team report";
            };
        }

    } catch (error) {
        console.error("Report loading error:", error);
        const projectBody = document.getElementById("project-summary-body");
        const teamBody = document.getElementById("team-summary-body");
        if (projectBody) projectBody.innerHTML = `<tr><td colspan="6">Unable to load project report.</td></tr>`;
        if (teamBody) teamBody.innerHTML = `<tr><td colspan="4">Unable to load team report.</td></tr>`;
    }
}

function renderCards(p, t, c, i, o, cp, ip, op) {
    document.getElementById("report-cards").innerHTML = `
        <div class="card"><h4>Total Projects</h4><h2>${p}</h2></div>
        <div class="card"><h4>Total Tasks</h4><h2>${t}</h2></div>
        <div class="card green"><h4>Completed</h4><h2>${c}</h2><small>${cp}%</small></div>
        <div class="card orange"><h4>In Progress</h4><h2>${i}</h2><small>${ip}%</small></div>
        <div class="card red"><h4>Overdue</h4><h2>${o}</h2><small>${op}%</small></div>
    `;
}

function renderCharts(projects, tasks, completed, inProgress, overdue) {

    // destroy old charts
    Chart.getChart("statusChart")?.destroy();
    Chart.getChart("lineChart")?.destroy();
    Chart.getChart("priorityChart")?.destroy();

    const statusCtx = document.getElementById("statusChart");
    const lineCtx = document.getElementById("lineChart");
    const priorityCtx = document.getElementById("priorityChart");

    if (!statusCtx || !lineCtx || !priorityCtx) return;

    const completedColor = getStatusColorToken("completed");
    const progressColor = getStatusColorToken("progress");
    const overdueColor = getStatusColorToken("hold");
    const pendingColor = getStatusColorToken("pending");

    Chart.defaults.font.family = "Arial, sans-serif";
    Chart.defaults.font.size = 12;
    Chart.defaults.color = "#0b1538";

    const totalTasks = tasks.length;
    const completedPercent = totalTasks ? Math.round((completed / totalTasks) * 100) : 0;
    const progressPercent = totalTasks ? Math.round((inProgress / totalTasks) * 100) : 0;
    const overduePercent = totalTasks ? Math.round((overdue / totalTasks) * 100) : 0;
    const statusLegend = document.getElementById("status-chart-legend");
    const statusTotal = document.getElementById("status-chart-total");
    const projectTotal = document.getElementById("project-chart-total");

    if (statusLegend) {
        statusLegend.innerHTML = `
            <div><span class="legend-dot completed"></span><strong>Completed</strong><small>${completed} (${completedPercent}%)</small></div>
            <div><span class="legend-dot in-progress"></span><strong>In Progress</strong><small>${inProgress} (${progressPercent}%)</small></div>
            <div><span class="legend-dot on-hold"></span><strong>Overdue</strong><small>${overdue} (${overduePercent}%)</small></div>
        `;
    }
    if (statusTotal) statusTotal.textContent = `Total: ${totalTasks} task${totalTasks === 1 ? "" : "s"}`;
    if (projectTotal) projectTotal.textContent = `Total: ${totalTasks} task${totalTasks === 1 ? "" : "s"}`;

    // ===== STATUS =====
    new Chart(statusCtx, {
        type: "doughnut",
        data: {
            labels: ["Completed", "In Progress", "Overdue"],
            datasets: [{
                data: [completed, inProgress, overdue],
                backgroundColor: [completedColor, progressColor, overdueColor],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: "54%",
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: ctx => `${ctx.label}: ${ctx.parsed} task${ctx.parsed === 1 ? "" : "s"}`
                    }
                }
            }
        }
    });

    // ===== LINE =====
    const map = {};
    tasks.forEach(t => {
        if (normalizeReportStatus(t.status) === "done") {
            const d = t.deadline || "No date";
            map[d] = (map[d] || 0) + 1;
        }
    });
    const sortedDates = Object.keys(map).sort();

    new Chart(lineCtx, {
        type: "line",
        data: {
            labels: sortedDates.map(formatReportChartDate),
            datasets: [{
                label: "Completed Tasks",
                data: sortedDates.map(date => map[date]),
                borderColor: completedColor,
                backgroundColor: "rgba(22, 163, 74, 0.12)",
                pointBackgroundColor: completedColor,
                pointBorderColor: completedColor,
                pointRadius: 4,
                pointHoverRadius: 5,
                tension: 0.35,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: { grid: { display: false }, ticks: { color: "#0b1538" } },
                y: { beginAtZero: true, grid: { color: "#e7edf6" }, ticks: { color: "#34405f", precision: 0 } }
            },
            plugins: {
                legend: {
                    position: "bottom",
                    labels: { usePointStyle: true, boxWidth: 8, color: "#27365f" }
                }
            }
        }
    });

    const projectLabels = [];
    const projectCounts = [];
    (projects || []).forEach(project => {
        const count = tasks.filter(task => String(task.project_id) === String(project.id)).length;
        if (count > 0) {
            projectLabels.push(formatProjectChartLabel(project.name || "Untitled Project"));
            projectCounts.push(count);
        }
    });

    new Chart(priorityCtx, {
        type: "bar",
        data: {
            labels: projectLabels,
            datasets: [{
                label: "Tasks",
                data: projectCounts,
                backgroundColor: [completedColor, progressColor, "#14b8a6", pendingColor, "#64748b", overdueColor],
                borderRadius: 4,
                maxBarThickness: 38
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: { grid: { display: false }, ticks: { color: "#0b1538", maxRotation: 0, minRotation: 0 } },
                y: { beginAtZero: true, grid: { color: "#e7edf6" }, ticks: { color: "#34405f", precision: 0 } }
            },
            plugins: {
                legend: { display: false }
            }
        }
    });
}

function renderProjectSummary(projects, tasks) {
    const body = document.getElementById("project-summary-body");
    if (!body) return;

    const displayProjects = showAllProjects ? projects : projects.slice(0, 4);

    let html = "";

    displayProjects.forEach(p => {
        const projectTasks = tasks.filter(t => String(t.project_id) === String(p.id));

        const total = projectTasks.length;
        const completed = projectTasks.filter(t => normalizeReportStatus(t.status) === "done").length;
        const inProgress = projectTasks.filter(t => normalizeReportStatus(t.status) === "in progress").length;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const overdue = projectTasks.filter(t =>
            t.deadline && new Date(`${t.deadline}T00:00:00`) < today && normalizeReportStatus(t.status) !== "done"
        ).length;

        const percent = total ? Math.round((completed / total) * 100) : 0;

        html += `
        <tr>
            <td>${p.name}</td>
            <td>${total}</td>
            <td>${completed}</td>
            <td>${inProgress}</td>
            <td>${overdue}</td>
            <td>
                <div class="progress-bar">
                    <div class="progress-fill" style="width:${percent}%"></div>
                </div>
                ${percent}%
            </td>
        </tr>`;
    });

    body.innerHTML = html || `<tr><td colspan="6">No project data found for this report.</td></tr>`;
}

function renderTeamSummary(tasks) {
    const body = document.getElementById("team-summary-body");
    if (!body) return;

    const map = {};

    tasks.forEach(t => {
        getTaskAssignments(t).forEach(assignment => {
            const user = assignment.user_id || "Unknown";

            if (!map[user]) {
                map[user] = { total: 0, completed: 0 };
            }

            map[user].total++;
            if (normalizeMemberStatus(assignment.status) === "Completed") map[user].completed++;
        });
    });

    const users = Object.keys(map);
    const displayUsers = showAllTeam ? users : users.slice(0, 4);

    let html = "";

    displayUsers.forEach(user => {
        const total = map[user].total;
        const completed = map[user].completed;
        const percent = total ? Math.round((completed / total) * 100) : 0;

        const shortEmail = user.length > 17 
            ? user.substring(0, 17) + "..." 
            : user;

        html += `
        <tr>
            <td class="member-cell">
                <span class="avatar">${user[0].toUpperCase()}</span>
                <span title="${user}">${shortEmail}</span>
            </td>
            <td>${completed}</td>
            <td>${total}</td>
            <td>
                <div class="progress-bar">
                    <div class="progress-fill" style="width:${percent}%"></div>
                </div>
                ${percent}%
            </td>
        </tr>`;
    });

    body.innerHTML = html || `<tr><td colspan="4">No team data found for this report.</td></tr>`;
}

function openExportModal() {
    const modal = document.getElementById("export-report-modal");
    if (!modal) return;

    applyDashboardRoleVisibility();
    syncExportModalUI();
    modal.classList.remove("hidden");
    document.body.classList.add("export-modal-open");
}

function closeExportModal() {
    const modal = document.getElementById("export-report-modal");
    if (!modal) return;

    modal.classList.add("hidden");
    document.body.classList.remove("export-modal-open");
}

function toggleExportSection(section) {
    if (exportModalState.sections.has(section)) {
        exportModalState.sections.delete(section);
    } else {
        exportModalState.sections.add(section);
    }

    syncExportModalUI();
}

function selectExportFormat(format) {
    exportModalState.format = format;
    syncExportModalUI();
}

function syncExportModalUI() {
    document.querySelectorAll("[data-export-section]").forEach(card => {
        card.classList.toggle("selected", exportModalState.sections.has(card.dataset.exportSection));
    });

    document.querySelectorAll("[data-export-format]").forEach(card => {
        card.classList.toggle("selected", card.dataset.exportFormat === exportModalState.format);
    });
}

async function confirmReportExport() {
    if (!exportModalState.sections.size) {
        alert("Please select at least one report section.");
        return;
    }

    await exportCSV({
        sections: Array.from(exportModalState.sections),
        format: exportModalState.format,
        includeCharts: document.getElementById("export-include-charts")?.checked ?? true
    });
}

async function exportCSV(options = {}) {
    const { filteredProjects, filteredTasks, startDate, endDate } = reportState;
    const sections = new Set(options.sections || ["projects", "overview", "tasks", "team"]);
    const format = options.format || "csv";

    if (sessionStorage.getItem("role") === "user") {
        sections.delete("activity");
    }

    if (!Array.isArray(filteredTasks) || !filteredTasks.length) {
        alert("No report data available to export.");
        return;
    }

    const projectById = new Map((filteredProjects || []).map(project => [String(project.id), project.name || "Untitled Project"]));
    const completed = filteredTasks.filter(t => normalizeReportStatus(t.status) === "done").length;
    const inProgress = filteredTasks.filter(t => normalizeReportStatus(t.status) === "in progress").length;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const overdue = filteredTasks.filter(t =>
        t.deadline && new Date(`${t.deadline}T00:00:00`) < today && normalizeReportStatus(t.status) !== "done"
    ).length;

    const rows = [
        ["TaskFlow Report"],
        ["Date Range", startDate || "All", endDate || "All"]
    ];

    if (sections.has("overview")) {
        rows.push(
            [],
            ["Reports Overview"],
            ["Metric", "Value"],
            ["Total Projects", filteredProjects.length],
            ["Total Tasks", filteredTasks.length],
            ["Completed Tasks", completed],
            ["In Progress Tasks", inProgress],
            ["Overdue Tasks", overdue]
        );
    }

    if (sections.has("projects")) {
        rows.push(
            [],
            ["Projects Summary"],
            ["Project", "Total Tasks", "Completed", "In Progress", "Overdue", "Completion"]
        );

        filteredProjects.forEach(project => {
            const projectTasks = filteredTasks.filter(task => String(task.project_id) === String(project.id));
            const total = projectTasks.length;
            const projectCompleted = projectTasks.filter(task => normalizeReportStatus(task.status) === "done").length;
            const projectProgress = projectTasks.filter(task => normalizeReportStatus(task.status) === "in progress").length;
            const projectOverdue = projectTasks.filter(task =>
                task.deadline && new Date(`${task.deadline}T00:00:00`) < today && normalizeReportStatus(task.status) !== "done"
            ).length;
            const percent = total ? Math.round((projectCompleted / total) * 100) : 0;

            rows.push([
                project.name || "Untitled Project",
                total,
                projectCompleted,
                projectProgress,
                projectOverdue,
                `${percent}%`
            ]);
        });
    }

    if (sections.has("tasks")) {
        rows.push(
            [],
            ["Tasks Summary"],
            ["Project", "Task", "Assigned To", "Status", "Deadline"]
        );

        filteredTasks.forEach(task => {
            rows.push([
                projectById.get(String(task.project_id)) || "Unknown Project",
                task.title || "Untitled Task",
                getTaskAssignments(task).map(assignment => `${assignment.user_id} (${normalizeMemberStatus(assignment.status)})`).join(", ") || "Unassigned",
                normalizeMemberStatus(task.status),
                task.deadline ? formatDeadlineDate(task.deadline) : "No date"
            ]);
        });
    }

    if (sections.has("team")) {
        const teamMap = {};
        filteredTasks.forEach(task => {
            getTaskAssignments(task).forEach(assignment => {
                const user = assignment.user_id || "Unknown";
                if (!teamMap[user]) teamMap[user] = { total: 0, completed: 0 };
                teamMap[user].total++;
                if (normalizeMemberStatus(assignment.status) === "Completed") teamMap[user].completed++;
            });
        });

        rows.push(
            [],
            ["Team Performance"],
            ["Member", "Completed", "Total", "Completion"]
        );

        Object.keys(teamMap).forEach(user => {
            const total = teamMap[user].total;
            const teamCompleted = teamMap[user].completed;
            rows.push([user, teamCompleted, total, `${total ? Math.round((teamCompleted / total) * 100) : 0}%`]);
        });
    }

    if (sections.has("activity")) {
        const token = sessionStorage.getItem("token");
        try {
            const res = await fetch(`${BASE_URL}/activities`, {
                headers: { "Authorization": "Bearer " + token }
            });
            const logs = res.ok ? await res.json() : [];
            rows.push(
                [],
                ["Activity Log"],
                ["Timestamp", "User", "Action", "Details"]
            );
            (Array.isArray(logs) ? logs : []).forEach(log => {
                rows.push([
                    formatDateTime(log.timestamp),
                    log.user_email || "-",
                    log.action || "-",
                    [log.target, log.details].filter(Boolean).join(" - ") || "-"
                ]);
            });
        } catch (error) {
            console.error("Activity export failed", error);
        }
    }

    if (sections.has("comments")) {
        rows.push([], ["Comments & Updates"], ["No comment export data is available yet."]);
    }

    const csv = rows.map(row => row.map(csvEscape).join(",")).join("\n");
    const extension = format === "excel" ? "xls" : format === "pdf" ? "pdf" : "csv";
    const mimeType = format === "excel"
        ? "application/vnd.ms-excel;charset=utf-8;"
        : format === "pdf"
            ? "application/pdf;charset=utf-8;"
            : "text/csv;charset=utf-8;";
    const rangeLabel = startDate || endDate
        ? `-${startDate || "start"}-to-${endDate || "end"}`
        : "";

    const filename = `taskflow-report${rangeLabel}`;

    if (format === "pdf") {

        exportRealPDF(rows, filename);

    } else if (format === "excel") {

        exportExcel(rows, filename);

    } else {

        const blob = new Blob([csv], { type: mimeType });

        const url = URL.createObjectURL(blob);

        const anchor = document.createElement("a");

        anchor.href = url;

        anchor.download = `${filename}.csv`;

        document.body.appendChild(anchor);

        anchor.click();

        anchor.remove();

        URL.revokeObjectURL(url);
    }

    closeExportModal();
}

function csvEscape(value) {
    const text = String(value ?? "");
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function buildPrintableReportHtml(rows) {
    const safeRows = rows.map(row => row.map(value => String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")));

    return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>TaskFlow Report</title>
    <style>
        body { font-family: Arial, sans-serif; color: #0b1538; padding: 28px; }
        h1 { margin: 0 0 18px; }
        table { width: 100%; border-collapse: collapse; margin-top: 14px; }
        td { border: 1px solid #d9e1ee; padding: 8px 10px; font-size: 13px; }
        tr:has(td:only-child) td { background: #eef4ff; font-weight: 700; }
    </style>
</head>
<body>
    <h1>TaskFlow Report</h1>
    <table>
        ${safeRows.map(row => `<tr>${row.map(value => `<td>${value}</td>`).join("")}</tr>`).join("")}
    </table>
</body>
</html>`;
}

async function loadFiles() {
    const token = sessionStorage.getItem("token");
    const role = sessionStorage.getItem("role");
    const tbody = document.getElementById("files-table-body");
    const footer = document.getElementById("files-footer-copy");
    const storageCopy = document.getElementById("storage-copy");
    const storagePercent = document.getElementById("storage-percent");
    const storageFill = document.getElementById("storage-meter-fill");

    const uploadBtn = document.getElementById("uploadBtn");
    if (uploadBtn) {
        uploadBtn.style.display = role === "user" ? "none" : "";
    }

    if (!tbody) return;

    tbody.innerHTML = `<tr><td colspan="${getFilesTableColumnCount(role)}" class="empty-table">Loading files...</td></tr>`;

    try {
        if (!Array.isArray(assignableUsers) || !assignableUsers.length) {
            await loadAssignableUsers();
        }

        if ((role === "user" || role === "manager") && (!fileUploadProjects.length || !fileUploadTasks.length)) {
            await loadFileUploadWorkspaceData();
        }

        const res = await fetch(`${BASE_URL}/files`, {
            headers: { "Authorization": "Bearer " + token }
        });
        const files = await res.json();
        filesCache = Array.isArray(files) ? files : [];
        const totalBytes = filesCache.reduce((sum, file) => sum + (Number(file.size) || 0), 0);
        const percent = Math.min(100, Math.round((totalBytes / (100 * 1024 * 1024 * 1024)) * 100));

        if (storageCopy) storageCopy.textContent = `${formatSize(totalBytes)} used of 100 GB`;
        if (storagePercent) storagePercent.textContent = `${percent}%`;
        if (storageFill) storageFill.style.width = `${Math.max(percent, 2)}%`;
        renderFiles();
    } catch (error) {
        console.error(error);
        tbody.innerHTML = `<tr><td colspan="${getFilesTableColumnCount(role)}" class="empty-table">Unable to load files</td></tr>`;
    }
}

async function openFileUploadModal() {
    const role = sessionStorage.getItem("role");
    if (role === "user") {
        alert("Only admins and managers can upload and assign files.");
        return;
    }

    const modal = document.getElementById("file-upload-modal");
    if (!modal) return;

    resetFileUploadModal();
    modal.classList.remove("hidden");
    document.body.classList.add("file-upload-modal-open");

    await Promise.all([
        loadFileUploadWorkspaceData(),
        loadAssignableUsers()
    ]);

    renderFileProjectOptions();
    renderFileTaskOptions();
    renderFileAssigneeChips();
    renderFileAssigneeOptions();
    bindFileDropZone();
}

function closeFileUploadModal() {
    const modal = document.getElementById("file-upload-modal");
    if (modal) modal.classList.add("hidden");
    document.body.classList.remove("file-upload-modal-open");
    closeFileAssigneeMenu();
}

function resetFileUploadModal() {
    fileUploadSelectedFile = null;
    fileUploadSelectedAssignees = [];

    const input = document.getElementById("modal-file-input");
    const message = document.getElementById("file-upload-message");
    const selectedName = document.getElementById("selectedFileName");
    const dropTitle = document.getElementById("fileDropTitle");
    const dropSubtitle = document.getElementById("fileDropSubtitle");
    const taskSelect = document.getElementById("file-task-select");
    const assigneeSearch = document.getElementById("file-assignee-search");
    const submit = document.getElementById("send-file-btn");

    if (input) input.value = "";
    if (message) message.value = "";
    if (taskSelect) taskSelect.innerHTML = `<option value="">Select a project first</option>`;
    if (assigneeSearch) assigneeSearch.value = "";
    if (selectedName) selectedName.textContent = "Max file size: 100 MB";
    if (dropTitle) dropTitle.textContent = "Drag & drop your file here";
    if (dropSubtitle) dropSubtitle.textContent = "or";
    if (submit) submit.disabled = false;
    updateFileUploadProgress(0, false);

    updateFileUploadMessageCount();
}

function updateFileUploadProgress(percent = 0, visible = false) {
    const progressWrap = document.getElementById("file-upload-progress-wrap");
    const progressFill = document.getElementById("file-upload-progress-fill");
    const progressText = document.getElementById("file-upload-progress-text");

    const normalized = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
    if (progressWrap) progressWrap.classList.toggle("hidden", !visible);
    if (progressFill) progressFill.style.width = `${normalized}%`;
    if (progressText) progressText.textContent = `${normalized}%`;
}

function uploadAssignedFileWithProgress(url, token, formData, onProgress) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Authorization", "Bearer " + token);

        xhr.upload.onprogress = event => {
            if (!event.lengthComputable) return;
            const percent = (event.loaded / event.total) * 100;
            if (typeof onProgress === "function") onProgress(percent);
        };

        xhr.onerror = () => reject(new Error("Network error during upload"));
        xhr.onload = () => {
            let body = {};
            if (xhr.responseText) {
                try {
                    body = JSON.parse(xhr.responseText || "{}");
                } catch (error) {
                    body = {};
                }
            }
            if (xhr.status >= 200 && xhr.status < 300) {
                resolve(body);
                return;
            }

            reject(new Error(body.detail || body.message || "Upload failed"));
        };

        xhr.send(formData);
    });
}

async function loadFileUploadWorkspaceData() {
    const token = sessionStorage.getItem("token");
    try {
        const [projectsRes, tasksRes] = await Promise.all([
            fetch(`${BASE_URL}/projects`, {
                headers: { "Authorization": "Bearer " + token }
            }),
            fetch(`${BASE_URL}/tasks`, {
                headers: { "Authorization": "Bearer " + token }
            })
        ]);
        const projects = await projectsRes.json().catch(() => []);
        const tasks = await tasksRes.json().catch(() => []);
        fileUploadProjects = Array.isArray(projects) ? projects : [];
        fileUploadTasks = Array.isArray(tasks) ? tasks : [];
    } catch (error) {
        console.error("Failed to load workspace data for file upload", error);
        fileUploadProjects = [];
        fileUploadTasks = [];
    }
}

function renderFileProjectOptions() {
    const select = document.getElementById("file-project-select");
    if (!select) return;

    if (!fileUploadProjects.length) {
        select.innerHTML = `<option value="">No projects available</option>`;
        select.disabled = true;
        return;
    }

    select.disabled = false;
    select.innerHTML = fileUploadProjects.map(project => `
        <option value="${escapeTeamHtml(project.id)}">${escapeTeamHtml(project.name || project.project_name || "Untitled Project")}</option>
    `).join("");
}

function getSelectedFileUploadProjectId() {
    return document.getElementById("file-project-select")?.value || "";
}

function getSelectedFileUploadTaskId() {
    return document.getElementById("file-task-select")?.value || "";
}

function getFileUploadProjectTasks() {
    const projectId = getSelectedFileUploadProjectId();
    if (!projectId) return [];
    return fileUploadTasks.filter(task => String(task.project_id) === String(projectId));
}

function renderFileTaskOptions() {
    const select = document.getElementById("file-task-select");
    if (!select) return;

    const tasks = getFileUploadProjectTasks();
    if (!getSelectedFileUploadProjectId()) {
        select.innerHTML = `<option value="">Select a project first</option>`;
        select.disabled = true;
        return;
    }

    if (!tasks.length) {
        select.innerHTML = `<option value="">No tasks in this project</option>`;
        select.disabled = true;
        return;
    }

    select.disabled = false;
    select.innerHTML = `
        <option value="">Select task</option>
        ${tasks.map(task => `
            <option value="${escapeTeamHtml(task.id)}">${escapeTeamHtml(task.title || task.task_title || "Untitled Task")}</option>
        `).join("")}
    `;
}

function handleFileUploadProjectChange() {
    fileUploadSelectedAssignees = [];
    closeFileAssigneeMenu();
    renderFileTaskOptions();
    renderFileAssigneeChips();
    renderFileAssigneeOptions();
}

function handleFileUploadTaskChange() {
    const allowedEmails = new Set(getFileUploadAssignableUsers().map(user => user.email));
    fileUploadSelectedAssignees = fileUploadSelectedAssignees.filter(email => allowedEmails.has(email));
    closeFileAssigneeMenu();
    renderFileAssigneeChips();
    renderFileAssigneeOptions();
}

function handleModalFileSelection(event) {
    const file = event.target.files?.[0];
    setFileUploadSelectedFile(file);
}

function setFileUploadSelectedFile(file) {
    if (!file) return;

    const maxBytes = 100 * 1024 * 1024;
    if (file.size > maxBytes) {
        alert("File is too large. Maximum size is 100 MB.");
        return;
    }

    fileUploadSelectedFile = file;

    const selectedName = document.getElementById("selectedFileName");
    const dropTitle = document.getElementById("fileDropTitle");
    const dropSubtitle = document.getElementById("fileDropSubtitle");

    if (selectedName) selectedName.textContent = `${file.name} - ${formatSize(file.size)}`;
    if (dropTitle) dropTitle.textContent = "File ready to send";
    if (dropSubtitle) dropSubtitle.textContent = "Choose another file if needed";
}

function bindFileDropZone() {
    const zone = document.getElementById("fileDropZone");
    if (!zone || zone.dataset.bound === "true") return;

    zone.dataset.bound = "true";

    ["dragenter", "dragover"].forEach(eventName => {
        zone.addEventListener(eventName, event => {
            event.preventDefault();
            zone.classList.add("drag-over");
        });
    });

    ["dragleave", "drop"].forEach(eventName => {
        zone.addEventListener(eventName, event => {
            event.preventDefault();
            zone.classList.remove("drag-over");
        });
    });

    zone.addEventListener("drop", event => {
        const file = event.dataTransfer?.files?.[0];
        setFileUploadSelectedFile(file);
    });
}

function toggleFileAssigneeMenu(event) {
    event.stopPropagation();
    const menu = document.getElementById("file-assignee-menu");
    if (menu) menu.classList.toggle("hidden");
}

function closeFileAssigneeMenu() {
    const menu = document.getElementById("file-assignee-menu");
    if (menu) menu.classList.add("hidden");
}

function toggleFileUploadAssignee(email) {
    const normalized = String(email || "").trim();
    if (!normalized) return;

    if (fileUploadSelectedAssignees.includes(normalized)) {
        fileUploadSelectedAssignees = fileUploadSelectedAssignees.filter(item => item !== normalized);
    } else {
        fileUploadSelectedAssignees.push(normalized);
    }

    renderFileAssigneeChips();
    renderFileAssigneeOptions();
}

function removeFileUploadAssignee(email, event) {
    if (event) event.stopPropagation();
    fileUploadSelectedAssignees = fileUploadSelectedAssignees.filter(item => item !== email);
    renderFileAssigneeChips();
    renderFileAssigneeOptions();
}

function getFileUploadAssignableUsers() {
    const taskId = getSelectedFileUploadTaskId();
    if (!taskId) return [];

    const task = fileUploadTasks.find(item => String(item.id) === String(taskId));
    if (!task) return [];

    const taskEmails = new Set(
        getTaskAssignments(task)
            .map(assignment => String(assignment.user_id || "").trim().toLowerCase())
            .filter(Boolean)
    );

    return assignableUsers.filter(user =>
        taskEmails.has(String(user.email || "").trim().toLowerCase())
    );
}

function renderFileAssigneeChips() {
    const chips = document.getElementById("file-assignee-chips");
    if (!chips) return;

    if (!fileUploadSelectedAssignees.length) {
        chips.textContent = "Select team members";
        chips.classList.add("empty");
        return;
    }

    chips.classList.remove("empty");
    chips.innerHTML = fileUploadSelectedAssignees.map(email => {
        const user = assignableUsers.find(item => item.email === email);
        const label = user?.username || email;
        return `
            <span class="file-assignee-chip">
                <strong>${escapeTeamHtml(getAvatarInitial(label))}</strong>
                ${escapeTeamHtml(label)}
                <button type="button" onclick="removeFileUploadAssignee('${escapeTeamHtml(email)}', event)" aria-label="Remove ${escapeTeamHtml(label)}">
                    <i class="fas fa-xmark"></i>
                </button>
            </span>
        `;
    }).join("");
}

function renderFileAssigneeOptions() {
    const list = document.getElementById("file-assignee-options");
    const search = document.getElementById("file-assignee-search");
    if (!list) return;

    const query = String(search?.value || "").trim().toLowerCase();
    const users = getFileUploadAssignableUsers().filter(user => {
        const text = `${user.username || ""} ${user.email || ""}`.toLowerCase();
        return !query || text.includes(query);
    });

    if (!users.length) {
        const emptyText = getSelectedFileUploadTaskId()
            ? "No assigned users found for this task"
            : "Select a task to view assigned users";
        list.innerHTML = `<p class="assign-empty">${emptyText}</p>`;
        return;
    }

    list.innerHTML = users.map(user => {
        const checked = fileUploadSelectedAssignees.includes(user.email);
        const label = user.username || user.email;
        return `
            <label class="file-assignee-option">
                <input type="checkbox" value="${escapeTeamHtml(user.email)}" ${checked ? "checked" : ""} onchange="toggleFileUploadAssignee('${escapeTeamHtml(user.email)}')">
                <span class="file-option-avatar">${escapeTeamHtml(getAvatarInitial(label))}</span>
                <span>
                    <strong>${escapeTeamHtml(label)}</strong>
                    <small>${escapeTeamHtml(user.email)}</small>
                </span>
            </label>
        `;
    }).join("");
}

function updateFileUploadMessageCount() {
    const message = document.getElementById("file-upload-message");
    const count = document.getElementById("file-upload-message-count");
    if (count) count.textContent = `${String(message?.value || "").length}/200`;
}

async function submitAssignedFile() {
    const role = sessionStorage.getItem("role");
    if (role === "user") {
        alert("Only admins and managers can upload and assign files.");
        return;
    }

    if (!fileUploadSelectedFile) {
        alert("Please choose a file first.");
        return;
    }

    const token = sessionStorage.getItem("token");
    const projectSelect = document.getElementById("file-project-select");
    const projectId = projectSelect?.value || "";
    const project = fileUploadProjects.find(item => String(item.id) === String(projectId));
    const taskId = getSelectedFileUploadTaskId();
    const task = fileUploadTasks.find(item => String(item.id) === String(taskId));
    const message = document.getElementById("file-upload-message")?.value || "";
    const submit = document.getElementById("send-file-btn");

    if (!taskId) {
        alert("Please select a task before assigning the file.");
        return;
    }

    try {
        if (submit) {
            submit.disabled = true;
            submit.querySelector("span").textContent = "Sending...";
        }
        updateFileUploadProgress(0, true);

        const formData = new FormData();
        formData.append("file", fileUploadSelectedFile);
        formData.append("project_id", projectId);
        formData.append("project_name", project?.name || project?.project_name || "");
        formData.append("task_id", taskId);
        formData.append("task_title", task?.title || task?.task_title || "");
        formData.append("message", message.trim());
        formData.append("shared_with", JSON.stringify(fileUploadSelectedAssignees));

        await uploadAssignedFileWithProgress(
            `${BASE_URL}/files/upload`,
            token,
            formData,
            percent => updateFileUploadProgress(percent, true)
        );
        updateFileUploadProgress(100, true);

        closeFileUploadModal();
        await loadFiles();
    } catch (error) {
        console.error(error);
        alert(error.message || "Upload failed");
    } finally {
        if (submit) {
            submit.disabled = false;
            submit.querySelector("span").textContent = "Send File";
        }
        setTimeout(() => updateFileUploadProgress(0, false), 500);
    }
}

function renderFiles() {
    const tbody = document.getElementById("files-table-body");
    const footer = document.getElementById("files-footer-copy");
    if (!tbody) return;
    bindFileAssigneePopoverPositioning();
    const role = sessionStorage.getItem("role");
    const table = document.querySelector(".files-table");
    if (table) {
        table.classList.remove("files-table-user", "files-table-manager", "files-table-admin");
        table.classList.add(`files-table-${role || "user"}`);
    }

    if (!fileAssigneeToggleBound) {
        tbody.addEventListener("click", (event) => {
            const toggle = event.target.closest(".dashboard-file-assigned-toggle");
            if (!toggle) return;
            const fileKey = String(toggle.dataset.fileKey || "").trim();
            if (!fileKey) return;
            event.preventDefault();
            toggleDashboardFileAssigneeRow(fileKey);
        });
        fileAssigneeToggleBound = true;
    }

    let items = [...filesCache];

    updateCategoryCounts();

    if (filesTab === "my") {
        const email = (sessionStorage.getItem("email") || "").trim().toLowerCase();
        items = items.filter(file => String(file.owner_email || file.owner || "").trim().toLowerCase() === email);
    } else if (filesTab === "shared") {
        const email = (sessionStorage.getItem("email") || "").trim().toLowerCase();
        items = items.filter(file => {
            const sharedWith = Array.isArray(file.shared_with) ? file.shared_with : [];
            return sharedWith.some(value => String(value || "").trim().toLowerCase() === email);
        });
    }

    if (filesCategory !== "all") {
        items = items.filter(file => getFileCategory(file) === filesCategory);
    }

    if (filesSort === "name-desc") {
        items.sort((a, b) => String(b.name || "").localeCompare(String(a.name || "")));
    } else if (filesSort === "date-desc") {
        items.sort((a, b) => new Date(b.uploaded_at || 0) - new Date(a.uploaded_at || 0));
    } else {
        items.sort((a, b) => String(a.name || "").localeCompare(String(b.name || "")));
    }

    const total = items.length;
    const totalPages = Math.max(1, Math.ceil(total / filesPageSize));
    filesPage = Math.min(filesPage, totalPages);
    const start = (filesPage - 1) * filesPageSize;
    const pageItems = items.slice(start, start + filesPageSize);

    if (footer) {
        const startItem = total === 0 ? 0 : start + 1;
        const endItem = Math.min(start + pageItems.length, total);
        footer.textContent = total
            ? `Showing ${startItem} to ${endItem} of ${total} files`
            : `Showing 0 files`;
    }

    if (!pageItems.length) {
        tbody.innerHTML = `<tr><td colspan="${getFilesTableColumnCount(role)}" class="empty-table">No files uploaded yet</td></tr>`;
        return;
    }

    tbody.innerHTML = "";

    const header = document.getElementById("assigned-header");
    if (header) {
        header.style.display = "";
    }
    const projectHeader = document.getElementById("file-project-header");
    const taskHeader = document.getElementById("file-task-header");
    if (projectHeader) {
        projectHeader.style.display = role === "user" || role === "manager" ? "" : "none";
    }
    if (taskHeader) {
        taskHeader.style.display = role === "user" ? "" : "none";
    }
    const currentEmail = (sessionStorage.getItem("email") || "").trim().toLowerCase();
    pageItems.forEach(file => {
        const row = document.createElement("tr");
        const fileKey = file.storage_name || file.name;
        const fileOwnerEmail = String(file.owner_email || "").trim().toLowerCase();
        const sharedWith = Array.isArray(file.shared_with) ? file.shared_with : [];
        const canDelete = role === "admin" || role === "manager" || fileOwnerEmail === currentEmail;
        const canDownload = role === "admin" || role === "manager" || fileOwnerEmail === currentEmail || sharedWith.some(value => String(value || "").trim().toLowerCase() === currentEmail);
        const actionButtons = [];

        if (canDownload) {
            actionButtons.push(`<button class="action-btn" type="button" onclick="downloadFile('${encodeURIComponent(fileKey)}')"><i class="fas fa-download"></i></button>`);
        }
        if (canDelete) {
            actionButtons.push(`<button class="delete-btn" type="button" onclick="deleteFile('${encodeURIComponent(fileKey)}')">Delete</button>`);
        }

        row.innerHTML = `
            <td><i class="far fa-star star-icon" onclick="toggleStar(this)"></i></td>
            <td>
                <span class="file-icon ${getFileIconClass(file)}">
                    <i class="${getFileIcon(file)}"></i>
                </span>
                ${shortenFileName(file.name)}
            </td>            
            <td>${file.owner_name || file.owner_email || sessionStorage.getItem("username") || "Unknown"}</td>

            <td>
                 ${renderDashboardFileAssignedTo(file)}
            </td>

            ${role === "user" || role === "manager" ? `
            <td>${escapeTeamHtml(file.project_name || getDashboardFileProjectName(file) || "No project")}</td>
            ` : ""}

            ${role === "user" ? `
            <td>${escapeTeamHtml(file.task_title || getDashboardFileTaskTitle(file) || "No task")}</td>
            ` : ""}
           
            <td>${file.size_label || formatSize(file.size)}</td>
            <td>${formatDateTime(file.uploaded_at)}</td>
            <td>${actionButtons.length ? actionButtons.join(" ") : `<span class="file-lock"><i class="fas fa-lock"></i></span>`}</td>
        `;
        tbody.appendChild(row);
    });

    updatePagination(totalPages);
}

function bindFileAssigneePopoverPositioning() {
    if (fileAssigneePopoverBound) return;

    const setActivePreview = (target) => {
        const preview = target?.closest?.(".file-assignee-preview");
        if (!preview) return;
        activeFileAssigneePreview = preview;
        positionFileAssigneePopover(preview);
    };

    document.addEventListener("pointerover", event => setActivePreview(event.target), true);
    document.addEventListener("focusin", event => setActivePreview(event.target), true);
    document.addEventListener("pointerout", event => {
        if (!activeFileAssigneePreview) return;
        if (activeFileAssigneePreview.contains(event.relatedTarget)) return;
        activeFileAssigneePreview = null;
    }, true);

    const repositionActivePopover = () => {
        if (activeFileAssigneePreview) {
            positionFileAssigneePopover(activeFileAssigneePreview);
        }
    };

    window.addEventListener("scroll", repositionActivePopover, true);
    window.addEventListener("resize", repositionActivePopover);
    fileAssigneePopoverBound = true;
}

function positionFileAssigneePopover(preview) {
    const popover = preview?.querySelector?.(".file-assignee-popover");
    if (!popover) return;

    const margin = 12;
    const rect = preview.getBoundingClientRect();
    const popoverWidth = popover.offsetWidth || 250;
    const popoverHeight = Math.min(popover.scrollHeight || popover.offsetHeight || 220, window.innerHeight - (margin * 2));
    let left = rect.left + Math.min(28, rect.width / 2);
    let top = rect.bottom + 8;

    if (left + popoverWidth > window.innerWidth - margin) {
        left = window.innerWidth - margin - popoverWidth;
    }
    if (left < margin) {
        left = margin;
    }

    if (top + popoverHeight > window.innerHeight - margin && rect.top > popoverHeight + margin) {
        top = rect.top - popoverHeight - 8;
    }
    if (top + popoverHeight > window.innerHeight - margin) {
        top = Math.max(margin, window.innerHeight - margin - popoverHeight);
    }

    popover.style.setProperty("--file-assignee-popover-left", `${Math.round(left)}px`);
    popover.style.setProperty("--file-assignee-popover-top", `${Math.round(top)}px`);
}

function renderDashboardFileAssignedTo(file) {
    const assigned = Array.isArray(file?.shared_with)
        ? file.shared_with.map(email => String(email || "").trim()).filter(Boolean)
        : [];

    if (!assigned.length) {
        return `<span class="dashboard-file-unassigned">Unassigned</span>`;
    }
    const visibleAssignees = assigned.slice(0, 3);
    const hiddenCount = Math.max(0, assigned.length - 3);
    const assigneeRows = assigned.map(email => {
        const user = getDashboardFileAssigneeUser(email);
        const name = user?.username || getUserDisplayName(email, getDashboardFileAssigneeSource());
        const initial = getAvatarInitial(name || email);
        return `
            <li class="file-assignee-popover-person">
                <span class="file-assignee-popover-avatar">${escapeTeamHtml(initial)}</span>
                <span>
                    <strong>${escapeTeamHtml(name)}</strong>
                    <small>${escapeTeamHtml(email)}</small>
                </span>
            </li>
        `;
    }).join("");

    return `
        <div class="dashboard-file-assigned-list file-assignee-preview" tabindex="0" aria-label="Assigned to ${assigned.length} people">
            <div class="file-assignee-avatar-stack">
            ${visibleAssignees.map(email => {
                const user = getDashboardFileAssigneeUser(email);
                const name = user?.username || getUserDisplayName(email, getDashboardFileAssigneeSource());
                return `
                    <span class="dashboard-file-assigned-pill file-assignee-avatar" title="${escapeTeamHtml(name)} (${escapeTeamHtml(email)})">
                        ${escapeTeamHtml(getAvatarInitial(name || email))}
                    </span>
                `;
            }).join("")}
            ${hiddenCount > 0
                ? `<span class="dashboard-file-assigned-more file-assignee-more">+${hiddenCount}</span>`
                : ""}
            </div>
            <div class="file-assignee-popover" role="tooltip">
                <div class="file-assignee-popover-head">
                    <strong>Assigned to</strong>
                    <span>People who have access to this file</span>
                </div>
                <ul>${assigneeRows}</ul>
                <p>Total ${assigned.length} ${assigned.length === 1 ? "person" : "people"}</p>
            </div>
        </div>
    `;
}

function getDashboardFileAssigneeSource() {
    const merged = [...(Array.isArray(assignableUsers) ? assignableUsers : [])];
    (Array.isArray(allUsersCache) ? allUsersCache : []).forEach(user => {
        const email = String(user?.email || "").trim().toLowerCase();
        if (email && !merged.some(item => String(item?.email || "").trim().toLowerCase() === email)) {
            merged.push(user);
        }
    });
    return merged;
}

function getDashboardFileAssigneeUser(email) {
    const lookup = String(email || "").trim().toLowerCase();
    return getDashboardFileAssigneeSource().find(user => String(user?.email || "").trim().toLowerCase() === lookup);
}

function getDashboardFileKey(file) {
    const base = String(file?.id || file?.file_id || file?.filename || file?.stored_name || file?.file_name || "").trim();
    const uploaded = String(file?.uploaded_at || file?.created_at || "").trim();
    return `${base}::${uploaded}`;
}

function toggleDashboardFileAssigneeRow(fileKey) {
    if (!fileKey) return;
    if (expandedFileAssigneeRows.has(fileKey)) {
        expandedFileAssigneeRows.delete(fileKey);
    } else {
        expandedFileAssigneeRows.add(fileKey);
    }
    renderFiles();
}

function getFilesTableColumnCount(role = sessionStorage.getItem("role")) {
    const effectiveRole = role || "user";
    if (effectiveRole === "user") return 9;
    if (effectiveRole === "manager") return 8;
    return 7;
}

function getDashboardFileProjectName(file) {
    const projectId = String(file?.project_id || "").trim();
    if (!projectId) return "";
    const project = [
        ...fileUploadProjects,
        ...(dashboardTaskCache.projects || []),
        ...(teamWorkspaceCache.projects || [])
    ].find(item => String(item.id) === projectId);
    return project?.name || project?.project_name || "";
}

function getDashboardFileTaskTitle(file) {
    const taskId = String(file?.task_id || "").trim();
    if (!taskId) return "";
    const task = [
        ...fileUploadTasks,
        ...(dashboardTaskCache.tasks || []),
        ...(teamWorkspaceCache.tasks || [])
    ].find(item => String(item.id) === taskId);
    return task?.title || task?.task_title || "";
}

function shortenFileName(name) {
    const base = name.split('.')[0]; // remove .pdf
    return base.length > 13 ? base.substring(0, 16) + "..." : base;
}

function updateCategoryCounts() {
    const counts = {
        all: filesCache.length,
        documents: 0,
        images: 0,
        videos: 0,
        archives: 0,
        others: 0
    };

    filesCache.forEach(file => {
        counts[getFileCategory(file)] += 1;
    });

    document.querySelectorAll("#category-list .category-item").forEach(item => {
        const category = item.dataset.category;
        const count = item.querySelector("strong");
        if (count) {
            count.textContent = String(counts[category] || 0);
        }
        item.classList.toggle("active", category === filesCategory);
        item.style.color = category === filesCategory ? "#159653" : "#41516a";
    });
}

function updatePagination(totalPages) {
    const pagination = document.getElementById("files-pagination");
    if (!pagination) return;

    pagination.innerHTML = `
        <div class="pagination app-pagination-controls">
            <button type="button" class="page-btn app-page-btn" onclick="setFilesPage(${Math.max(1, filesPage - 1)})" ${filesPage <= 1 ? "disabled" : ""} aria-label="Previous files page">
                <i class="fas fa-chevron-left"></i>
            </button>
            <span class="page-btn active app-page-current" aria-current="page">${filesPage}</span>
            <button type="button" class="page-btn app-page-btn" onclick="setFilesPage(${Math.min(totalPages, filesPage + 1)})" ${filesPage >= totalPages ? "disabled" : ""} aria-label="Next files page">
                <i class="fas fa-chevron-right"></i>
            </button>
        </div>
    `;
}

function setFilesTab(tab) {
    filesTab = tab;
    filesPage = 1;

    document.querySelectorAll(".files-tab").forEach(btn => btn.classList.remove("active"));
    const active = document.querySelector(`.files-tab[data-files-tab="${tab}"]`);
    if (active) active.classList.add("active");

    renderFiles();
}

function setFilesCategory(category) {
    filesCategory = category;
    filesPage = 1;

    const labelMap = {
        all: "All Files",
        documents: "Documents",
        images: "Images",
        videos: "Videos",
        archives: "Archives",
        others: "Others"
    };

    const label = labelMap[category] || category;
    const labelEl = document.getElementById("selected-category-label");
    if (labelEl) labelEl.textContent = label;

    closeCategoryDropdown();
    renderFiles();
}

function toggleCategoryDropdown() {
    const menu = document.getElementById("files-category-dropdown-menu");
    if (!menu) return;

    const storageMenu = document.getElementById("storage-dropdown-menu");
    if (storageMenu && !storageMenu.classList.contains("hidden")) {
        storageMenu.classList.add("hidden");
    }

    const sortOptions = document.getElementById("sortOptions");
    if (sortOptions) {
        sortOptions.classList.remove("show");
    }

    menu.classList.toggle("hidden");
}

function closeCategoryDropdown() {
    const menu = document.getElementById("files-category-dropdown-menu");
    if (menu && !menu.classList.contains("hidden")) {
        menu.classList.add("hidden");
    }
}

function toggleStorageDropdown() {
    const menu = document.getElementById("storage-dropdown-menu");
    if (!menu) return;
    const categoryMenu = document.getElementById("files-category-dropdown-menu");
    if (categoryMenu && !categoryMenu.classList.contains("hidden")) {
        categoryMenu.classList.add("hidden");
    }
    const sortOptions = document.getElementById("sortOptions");
    if (sortOptions) {
        sortOptions.classList.remove("show");
    }
    menu.classList.toggle("hidden");
}

function closeStorageDropdown() {
    const menu = document.getElementById("storage-dropdown-menu");
    if (menu && !menu.classList.contains("hidden")) {
        menu.classList.add("hidden");
    }
}

window.addEventListener("load", () => {
    applyDashboardRoleVisibility();
});

window.addEventListener("click", function(event) {
    const target = event.target;

    const categoryMenu = document.getElementById("files-category-dropdown-menu");
    const categoryButton = document.querySelector(".category-dropdown-btn");
    if (categoryMenu && categoryButton && !categoryMenu.classList.contains("hidden") && !categoryMenu.contains(target) && !categoryButton.contains(target)) {
        categoryMenu.classList.add("hidden");
    }

    const storageMenu = document.getElementById("storage-dropdown-menu");
    const storageButton = document.querySelector(".storage-dropdown-btn");
    if (storageMenu && storageButton && !storageMenu.classList.contains("hidden") && !storageMenu.contains(target) && !storageButton.contains(target)) {
        storageMenu.classList.add("hidden");
    }

    const fileAssigneeMenu = document.getElementById("file-assignee-menu");
    const fileAssigneeTrigger = document.getElementById("file-assignee-trigger");
    if (fileAssigneeMenu && fileAssigneeTrigger && !fileAssigneeMenu.classList.contains("hidden") && !fileAssigneeMenu.contains(target) && !fileAssigneeTrigger.contains(target)) {
        fileAssigneeMenu.classList.add("hidden");
    }

});

function toggleFilesSort() {
    const sortOptions = document.getElementById("sortOptions");
    if (!sortOptions) return;

    closeCategoryDropdown();
    closeStorageDropdown();
    sortOptions.classList.toggle("show");
}

function setSort(sortType) {

    filesSort = sortType;

    const label = document.querySelector(".files-sort span");

    if (label) {
        label.textContent =
            sortType === "name-asc"
            ? "Sort by: Name (A-Z)"
            : sortType === "name-desc"
            ? "Sort by: Name (Z-A)"
            : "Sort by: Date (Newest)";
    }

    document.getElementById("sortOptions").classList.remove("show");

    renderFiles();
}

function setFilesLayout(layout) {
    filesLayout = layout;
    document.querySelectorAll(".files-icon-btn").forEach(btn => btn.classList.remove("active"));
    const buttons = Array.from(document.querySelectorAll(".files-icon-btn"));
    if (layout === "list" && buttons[0]) buttons[0].classList.add("active");
    if (layout === "grid" && buttons[1]) buttons[1].classList.add("active");
}

function setFilesPage(page) {
    filesPage = page;
    renderFiles();
}

function changeFilesPage(delta) {
    const totalPages = Math.max(1, Math.ceil(filesCache.length / filesPageSize));
    filesPage = Math.min(totalPages, Math.max(1, filesPage + delta));
    renderFiles();
}

function createFolder() {
    alert("Folder creation is not connected yet.");
}

async function loadAssignableUsers() {
    const token = sessionStorage.getItem("token");
    try {
        if (!Array.isArray(allUsersCache) || !allUsersCache.length) {
            const usersRes = await fetch(`${BASE_URL}/users`, {
                headers: { "Authorization": "Bearer " + token }
            });
            allUsersCache = await usersRes.json().catch(() => []);
        }

        const source = Array.isArray(allUsersCache) ? allUsersCache.slice() : [];

        if (!Array.isArray(source)) {
            assignableUsers = [];
            assignableUsersLoaded = true;
            return;
        }

        assignableUsers = source
            .map(user => ({
                ...user,
                email: String(user.email || "").trim(),
                username: String(user.username || user.name || user.email || "").trim(),
                role: String(user.role || "").toLowerCase()
            }))
            .filter(user => user.email && user.role === "user")
            .sort((a, b) => a.email.localeCompare(b.email));
    } catch {
        assignableUsers = Array.isArray(allUsersCache) ? allUsersCache.slice() : [];
    }
    assignableUsersLoaded = true;
}

function getFileCategory(file) {
    const ext = (file.extension || "").toLowerCase();
    if (["doc", "docx", "pdf", "txt", "rtf", "odt"].includes(ext)) return "documents";
    if (["png", "jpg", "jpeg", "gif", "webp", "svg"].includes(ext)) return "images";
    if (["mp4", "mov", "avi", "mkv", "webm"].includes(ext)) return "videos";
    if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) return "archives";
    return "others";
}

async function handleFileUpload(event) {
    const token = sessionStorage.getItem("token");
    const selected = Array.from(event.target.files || []);
    if (!selected.length) return;

    try {
        for (const file of selected) {
            const formData = new FormData();
            formData.append("file", file);
            await fetch(`${BASE_URL}/files/upload`, {
                method: "POST",
                headers: { "Authorization": "Bearer " + token },
                body: formData
            });
        }
        event.target.value = "";
        loadFiles();
    } catch (error) {
        console.error(error);
        alert("Upload failed");
    }
}

async function downloadFile(filename) {
    const token = sessionStorage.getItem("token");
    const decoded = decodeURIComponent(filename);

    try {
        const res = await fetch(`${BASE_URL}/files/download/${encodeURIComponent(decoded)}`, {
            headers: { "Authorization": "Bearer " + token }
        });

        if (!res.ok) {
            const data = await res.json().catch(() => ({}));
            throw new Error(data.detail || data.message || "Download failed");
        }

        const blob = await res.blob();
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = decoded;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error(error);
        alert(error.message || "Could not download file");
    }
}

async function exportRealPDF(rows, filename) {

    const { jsPDF } = window.jspdf;

    const doc = new jsPDF("p", "mm", "a4");

    // Title
    doc.setFontSize(22);
    doc.text("TaskFlow Report", 70, 20);

    // Date
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 30);

    let currentY = 40;

    let headers = [];
    let body = [];

    rows.forEach((row) => {

        // Section title
        if (row.length === 1) {

            // Print previous table first
            if (headers.length && body.length) {

                doc.autoTable({
                    startY: currentY,
                    head: [headers],
                    body: body,
                    theme: "grid",
                    styles: {
                        fontSize: 8,
                        cellPadding: 3,
                        overflow: "linebreak"
                    },
                    headStyles: {
                        fillColor: [41, 128, 185]
                    }
                });

                currentY = doc.lastAutoTable.finalY + 10;

                headers = [];
                body = [];
            }

            // Section heading
            doc.setFontSize(14);
            doc.setTextColor(41, 128, 185);

            doc.text(String(row[0]), 14, currentY);

            currentY += 8;
        }

        // Header row
        else if (!headers.length) {

            headers = row;

        }

        // Table body
        else {

            body.push(row);
        }

    });

    // Final table
    if (headers.length && body.length) {

        doc.autoTable({
            startY: currentY,
            head: [headers],
            body: body,
            theme: "grid",
            styles: {
                fontSize: 8,
                cellPadding: 3,
                overflow: "linebreak"
            },
            headStyles: {
                fillColor: [41, 128, 185]
            }
        });

    }

    const pdfBlob = doc.output("blob");

    const handle = await window.showSaveFilePicker({

        suggestedName: filename + ".pdf",

        types: [
            {
                description: "PDF File",
                accept: {
                    "application/pdf": [".pdf"]
                }
            }
        ]
    });

    const writable = await handle.createWritable();

    await writable.write(pdfBlob);

    await writable.close();
}

async function exportExcel(rows, filename) {

    const worksheet = XLSX.utils.aoa_to_sheet(rows);

    worksheet["!cols"] = [
        { wch: 40 },
        { wch: 30 },
        { wch: 30 },
        { wch: 20 },
        { wch: 20 },
        { wch: 20 }
    ];

    const workbook = XLSX.utils.book_new();

    XLSX.utils.book_append_sheet(workbook, worksheet, "Report");

    const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array"
    });

    const blob = new Blob(
        [excelBuffer],
        {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }
    );

    const handle = await window.showSaveFilePicker({

        suggestedName: filename + ".xlsx",

        types: [
            {
                description: "Excel File",
                accept: {
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"]
                }
            }
        ]
    });

    const writable = await handle.createWritable();

    await writable.write(blob);

    await writable.close();
}

async function deleteFile(filename) {
    const token = sessionStorage.getItem("token");
    const decoded = decodeURIComponent(filename);
    if (!confirm(`Delete ${decoded}?`)) return;

    const res = await fetch(`${BASE_URL}/files/${encodeURIComponent(decoded)}`, {
        method: "DELETE",
        headers: { "Authorization": "Bearer " + token }
    });

    if (res.ok) {
        loadFiles();
    } else {
        alert("Could not delete file");
    }
}

function getFileIconClass(file) {
    const ext = (file.extension || "").toLowerCase();
    if (ext === "pdf") return "pdf";
    if (ext === "doc" || ext === "docx") return "doc";
    if (ext === "xls" || ext === "xlsx") return "xls";
    if (ext === "ppt" || ext === "pptx") return "ppt";
    if (["png", "jpg", "jpeg", "gif"].includes(ext)) return "img";
    if (["zip", "rar", "7z"].includes(ext)) return "zip";
    return "folder";
}

function getFileIcon(file) {
    const map = {
        pdf: "fas fa-file-pdf",
        doc: "fas fa-file-word",
        xls: "fas fa-file-excel",
        ppt: "fas fa-file-powerpoint",
        img: "fas fa-image",
        zip: "fas fa-file-zipper",
        folder: "fas fa-folder"
    };
    return map[getFileIconClass(file)] || "fas fa-file";
}

function formatSize(bytes) {
    const value = Number(bytes) || 0;
    if (!value) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    let size = value;
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex += 1;
    }
    return `${size.toFixed(unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
}

function formatDateTime(value) {
    if (!value) return "—";

    const date = new Date(value);

    return date.toLocaleString("en-US", {
        month: "long",
        day: "numeric",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
    });
}

async function initializeDashboardPage() {
    if (dashboardPageInitialized) {
        return;
    }
    dashboardPageInitialized = true;

    if (typeof applySettingsPreferences === "function") {
        applySettingsPreferences();
    }

    bindDashboardThemePreference();
    startNotificationClock();

    applyDashboardRoleVisibility();

    let defaultView = sessionStorage.getItem("settings.defaultView") || "dashboard";
    if ((defaultView === "activity-log" || defaultView === "report") && sessionStorage.getItem("role") === "user") {
        defaultView = "files";
    }
    setProjectTab(defaultView);

    if (typeof loadAssignableUsers === "function") {
        await loadAssignableUsers();
    }
}

window.addEventListener("load", () => {
    initializeDashboardPage();
    loadDashboardSummary();
});

function toggleNotifications(event) {

    event.stopPropagation();

    const dropdown = document.getElementById("notification-dropdown");

    dropdown.classList.toggle("show");
}

document.addEventListener("click", function () {

    document
    .getElementById("notification-dropdown")
    .classList.remove("show");
});

async function loadNotifications() {

    const token = sessionStorage.getItem("token");

    try {

        const res = await fetch(`${BASE_URL}/notifications`, {

            headers: {
                "Authorization": "Bearer " + token
            }
        });

        const notifications = await res.json();
        allNotifications = notifications;
        renderNotifications();
        return;

        const list =
            document.getElementById("notification-list");

        const count =
            document.getElementById("notification-count");

        if (!list) return;

        list.innerHTML = "";

        const unreadCount =
            notifications.filter(n => !n.read).length;

        if (unreadCount > 0) {

            count.style.display = "flex";

            count.innerText = unreadCount;

        } else {

            count.style.display = "none";
        }

        if (notifications.length === 0) {

            list.innerHTML = `
                <div class="notification-empty">
                    No notifications
                </div>
            `;

            return;
        }

        notifications.forEach(notification => {

            list.innerHTML += `
            
            <div class="notification-item ${notification.read ? "" : "unread"}">

                <div class="notification-icon blue">
                    <i class="fas fa-tasks"></i>
                </div>

                <div class="notification-content">

                    <h4>${notification.title}</h4>

                    <p>${notification.message}</p>

                    <small>${notification.time}</small>

                </div>

            </div>
            `;
        });

    } catch(error) {

        console.log(error);
    }
}

window.addEventListener("load", loadNotifications);

setInterval(() => {
    if (document.documentElement.dataset.realtimeStatus !== "connected") {
        loadNotifications();
    }
}, 60000);

document.addEventListener("taskflow:realtime-status", (event) => {
    if (event?.detail?.status === "connected") {
        loadNotifications();
    }
});

function renderNotifications() {

    const list =
        document.getElementById("notification-list");

    const count =
        document.getElementById("notification-count");

    if (!list) return;

    const unreadCount =
        allNotifications.filter(n => !n.read).length;

    if (unreadCount > 0) {

        count.style.display = "flex";

        count.innerText = unreadCount;

    } else {

        count.style.display = "none";
    }

    list.innerHTML = "";

    let filtered = allNotifications;

    if (currentFilter === "unread") {

        filtered = allNotifications.filter(n => !n.read);
    }

    if (currentFilter === "mentions") {

        filtered = allNotifications.filter(n =>
            n.message?.includes("@")
        );
    }

    if (filtered.length === 0) {

        list.innerHTML = `
            <div class="notification-empty">
                No notifications
            </div>
        `;

        return;
    }

    filtered.forEach(notification => {
        const rawTime = notification.time || notification.created_at;
        const exactTime = formatNotificationTime(rawTime);
        const liveTime = formatNotificationTimeAgo(rawTime);

        list.innerHTML += `
        
        <div class="notification-item ${notification.read ? "" : "unread"}"
                onclick="markNotificationRead('${notification.id}')">

            <div class="notification-icon blue">
                <i class="fas fa-tasks"></i>
            </div>

            <div class="notification-content">

                <h4>${notification.title}</h4>

                <p>${notification.message}</p>

                <small title="${exactTime}">
                    ${liveTime}
                </small>

            </div>

        </div>
        `;
    });
}

function setNotificationFilter(filter, event) {

    event.stopPropagation();

    currentFilter = filter;

    document
        .querySelectorAll(".notification-tabs button")
        .forEach(btn =>
            btn.classList.remove("active-tab")
        );

    event.target.classList.add("active-tab");

    renderNotifications();
}

async function markNotificationRead(id) {

    const token = sessionStorage.getItem("token");

    try {

        const response = await fetch(

            `${BASE_URL}/notifications/${id}/read`,

            {
                method: "PUT",

                headers: {
                    "Authorization": "Bearer " + token
                }
            }
        );

        if (!response.ok) {

            throw new Error("Failed");
        }

        allNotifications = allNotifications.map(notification => {

            if (
                notification._id === id ||
                notification.id === id
            ) {

                notification.read = true;
            }

            return notification;
        });

        renderNotifications();

    } catch(error) {

        console.log(error);
    }
}

async function markAllNotificationsRead(event) {

    event.stopPropagation();

    const token = sessionStorage.getItem("token");

    try {

        const response = await fetch(

            `${BASE_URL}/notifications/read-all`,

            {
                method: "PUT",

                headers: {
                    "Authorization": "Bearer " + token
                }
            }
        );

        const data = await response.json();

        console.log(data);

        if (!response.ok) {

            throw new Error("Failed");
        }

        allNotifications = allNotifications.map(notification => ({

            ...notification,

            read: true
        }));

        renderNotifications();

    } catch(error) {

        console.log(error);
    }
}

function formatNotificationTime(timeString) {
    const date = parseNotificationDate(timeString);
    if (Number.isNaN(date.getTime())) return "Just now";

    return date.toLocaleString("en-IN", {

        timeZone: "Asia/Kolkata",

        day: "numeric",

        month: "short",

        year: "numeric",

        hour: "2-digit",

        minute: "2-digit",

        hour12: true
    });
}

function formatNotificationTimeAgo(timeString) {
    const date = parseNotificationDate(timeString);
    if (Number.isNaN(date.getTime())) return "Just now";

    const seconds = Math.max(Math.floor((Date.now() - date.getTime()) / 1000), 0);
    if (seconds < 60) return "Just now";

    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} min ago`;

    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours === 1 ? "" : "s"} ago`;

    const days = Math.floor(hours / 24);
    if (days < 7) return `${days} day${days === 1 ? "" : "s"} ago`;

    return formatNotificationTime(timeString);
}

function parseNotificationDate(value) {
    if (value instanceof Date) return value;
    const raw = String(value || "").trim();
    if (!raw) return new Date("");
    const normalized = /(?:z|[+\-]\d{2}:\d{2})$/i.test(raw) ? raw : `${raw}Z`;
    return new Date(normalized);
}

function startNotificationClock() {
    if (notificationClock) return;
    notificationClock = window.setInterval(() => {
        const list = document.getElementById("notification-list");
        if (list && !list.querySelector(".notification-empty")) {
            renderNotifications();
        }
    }, 30000);
}
